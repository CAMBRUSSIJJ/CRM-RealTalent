# WhatsApp por QR code e avisos de tarefas

Esta integração usa **Evolution API v2**, com uma instância WHATSAPP-BAILEYS por workspace. O software pode ser hospedado por você sem tarifa por mensagem; hospedagem, domínio e manutenção podem ter custo. A conexão não é a API oficial da Meta: pode desconectar e está sujeita a bloqueios pelo WhatsApp. A integração WhatsApp Cloud existente continua disponível.

## Opção sem Railway: Linux ou Mac ligado

Use o [guia do conector local](deploy/local-whatsapp/README.md). O QR aparece no CRM e o computador busca os comandos e os avisos pelo Supabase, sem portas públicas ou servidor Evolution alugado. O site pode ser publicado no Cloudflare Pages Free, respeitando as quotas, e a conexão do WhatsApp depende do computador ligado.

## Backend com Evolution em servidor público (opcional)

**Se você usa Railway:** siga o passo a passo em [deploy/railway/README.md](deploy/railway/README.md), com os arquivos de implantação e o agendamento no Supabase.

1. Instale a Evolution seguindo a documentação oficial: https://doc.evolution-api.com/ . Use uma versão v2 fixa e mantenha seu banco PostgreSQL, Redis e volumes de sessões persistentes. Publique por HTTPS, com autenticação ativa. Não exponha banco ou Redis publicamente.
2. Aplique as migrations do projeto, incluindo `supabase/migrations/202611050001_task_assignment_whatsapp.sql`, no seu projeto Supabase. Revise antes de aplicar em produção.
3. Nos **segredos das Edge Functions do Supabase**, configure `EVOLUTION_API_URL` (URL HTTPS), `EVOLUTION_API_KEY` (chave do servidor Evolution) e `WHATSAPP_TASK_WORKER_SECRET` (segredo aleatório com pelo menos 32 caracteres). Não coloque essas chaves no frontend, no Git ou em variáveis VITE_.
4. Publique `whatsapp-session` e `whatsapp-task-worker` pelo fluxo Supabase do projeto.
5. Configure um agendador privado, a cada minuto, para fazer POST a `https://<projeto>.supabase.co/functions/v1/whatsapp-task-worker`, com o cabeçalho `x-worker-secret` obtido de um cofre de segredos. O worker não deve ser chamado pelo navegador. Não grave o segredo em SQL versionado.
6. A rede das funções precisa alcançar o servidor Evolution; o servidor Evolution precisa alcançar o WhatsApp. Se usar rede restrita neste ambiente de desenvolvimento, adicione o domínio real da Evolution às configurações de rede. Não é necessário adicionar credenciais Evolution ao ambiente do frontend.

## Uso

Em **Configurações → Integrações → WhatsApp por QR code**, um administrador gera o código. No celular, abra **WhatsApp → Dispositivos conectados → Conectar dispositivo**. O painel consulta a conexão a cada cinco segundos e remove o QR quando conectar ou expirar; gere outro se necessário.

O administrador ativa os avisos do workspace. Cada integrante salva **seu próprio número com país e DDD** e autoriza os avisos. Em **Follow-ups → Nova atividade/Editar atividade**, selecione o responsável. O backend registra o aviso interno e coloca a mensagem na fila na criação com responsável ou na troca de responsável. Atribuições antigas não são disparadas retroativamente. Notas e tarefas concluídas não geram novos avisos.

O modo local permite selecionar o responsável, mas **não conecta WhatsApp nem envia mensagens**. Para usar a integração real, configure VITE_DATA_MODE=supabase, a URL e a chave pública do Supabase.

## Entrega e falhas

O gatilho no banco cobre atribuições feitas pela interface, importações e automações que gravam em activities. Alterar só título ou prazo não duplica o aviso. Remover/trocar responsável cancela mensagens ainda na fila; o worker também confere responsável, conclusão, associação ao workspace e autorização antes de enviar.

A fila é reivindicada atomicamente e tem até cinco tentativas com espera crescente. Falhas de autenticação e entregas incertas vão para revisão, sem reenvio cego. O painel lista os últimos resultados e erros. “Enviado ao WhatsApp” significa aceitação pelo serviço, não confirmação de leitura. Se uma pessoa retirar a autorização, os avisos pendentes dela são cancelados. Um envio já em andamento pode terminar.

Confira a conexão em caso de falha, gere um novo QR e verifique se o agendador está ativo. Confira entregas incertas diretamente no WhatsApp antes de qualquer reenvio manual. Nunca exponha logs ou payloads do provedor com a chave.

## Validação

`npm test` cobre isolamento da instância, formato do QR, permissões dos endpoints, envio pelo worker, cancelamento após troca de responsável, retentativas, entregas incertas, tratamento seguro de erros e ausência de envio no modo local. A validação real exige o backend publicado, uma Evolution disponível e leitura do QR por um administrador; o código não simula esse resultado.
