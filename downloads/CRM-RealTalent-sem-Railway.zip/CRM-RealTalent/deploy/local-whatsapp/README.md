# CRM e WhatsApp sem hospedar serviços no Railway

A integração está no CRM. Esta opção executa a Evolution e o conector no seu **Linux ou Mac**, usando Docker. O conector faz conexões de saída com o Supabase; você não precisa publicar a Evolution na internet, abrir portas no roteador nem contratar domínio.

O site pode ficar no **Cloudflare Pages Free** e o banco no **Supabase Free**, respeitando os limites desses planos. O WhatsApp depende do computador ligado, conectado à internet e sem suspensão. Não há aluguel de servidor para a Evolution; energia, internet e eventuais serviços fora dos planos gratuitos continuam por sua conta.

## 1. Preparar o Supabase

Antes de começar, instale Node.js 22 e Docker com Compose no seu computador e extraia os arquivos do projeto. Abra um terminal na pasta que contém `package.json`. Você também precisará de contas gratuitas no Supabase e Cloudflare.

Use o projeto Supabase que o CRM já utiliza ou crie um no plano **Free**, sem upgrade para plano pago.

1. No Dashboard Supabase, abra o projeto e copie seu **Project Ref** (o identificador na URL `https://IDENTIFICADOR.supabase.co`). Se o projeto já tiver dados, preserve um backup antes de aplicar alterações no banco. No terminal, execute, substituindo `SEU_PROJECT_REF`:

   ```bash
   npx supabase login
   npx supabase link --project-ref SEU_PROJECT_REF
   npx supabase db push
   ```

   O login pode abrir o navegador, e o vínculo pode solicitar a senha do banco no seu terminal. As migrations pendentes serão aplicadas, incluindo:
   - `202611050001_task_assignment_whatsapp.sql`
   - `202611050002_local_whatsapp_bridge.sql`
   Se o CLI indicar conflito de histórico de migrations, preserve o banco e investigue a mensagem antes de continuar; não use reset para contornar o erro.
2. Em **Edge Functions → Secrets**, salve **`WHATSAPP_CONNECTION_MODE=bridge`**, ou execute `npx supabase secrets set WHATSAPP_CONNECTION_MODE=bridge`. As chaves da Evolution ficam no computador; este modo não exige uma URL Evolution pública.
3. Publique novamente `whatsapp-session` e `whatsapp-task-worker` a partir deste código. Com o CLI Supabase já vinculado ao projeto:

   ```bash
   npx supabase functions deploy whatsapp-session
   npx supabase functions deploy whatsapp-task-worker
   ```

4. Se você já ativou o agendamento da versão Railway, desative o job `realtalent-whatsapp-tasks` em **Cron**. O conector local assume o envio. O worker da nuvem também deixa de consumir a fila quando o modo é `bridge`.

## 2. Publicar o CRM sem Railway

Envie estas alterações ao seu repositório GitHub. No **Cloudflare → Workers & Pages → Pages**, crie um projeto conectando esse repositório e escolha o plano gratuito:

| Campo | Valor |
| --- | --- |
| Framework | None |
| Build command | `npm run validate:env && npm run build` |
| Build output directory | `dist` |
| Root directory | raiz do repositório |

Nas variáveis do build configure:

| Nome | Valor |
| --- | --- |
| `NODE_VERSION` | `22.23.4` |
| `VITE_DATA_MODE` | `supabase` |
| `VITE_SUPABASE_URL` | URL HTTPS do seu projeto Supabase |
| `VITE_SUPABASE_PUBLISHABLE_KEY` | Chave **pública** do projeto |
| `VITE_RELEASE_CHANNEL` | `production` |

Use o endereço `*.pages.dev` fornecido pelo Cloudflare; domínio próprio não é necessário. O arquivo `public/_headers` inclui os cabeçalhos de segurança. O build copia esse arquivo para `dist/`.

No Supabase, configure a URL do novo site em **Authentication → URL Configuration**, incluindo os redirects usados no login e na recuperação de senha. Abra o novo site e confira login e dados antes de encerrar a hospedagem antiga.

### Alternativa: publicar sem configurar o GitHub

Você pode gerar o site no computador e enviar a pasta pronta ao Pages:

1. Na raiz do projeto, execute `test -e .env.local || cp .env.example .env.local`.
2. Abra `.env.local` em um editor e configure `VITE_DATA_MODE=supabase`, `VITE_SUPABASE_URL`, `VITE_SUPABASE_PUBLISHABLE_KEY` (somente a chave pública) e `VITE_RELEASE_CHANNEL=production`.
3. Na mesma pasta, execute:

   ```bash
   npm ci --include=dev
   npm run validate:env
   node --env-file=.env.local scripts/build-registry-independent.mjs
   ```

4. No Cloudflare Pages, crie um projeto com **upload de arquivos** e envie a pasta **`dist`** gerada. Não envie a pasta inteira do projeto nem arquivos `.env`.
5. Use o endereço `*.pages.dev` e configure-o também em Authentication no Supabase, como descrito acima.

O comando com `--env-file` carrega sua configuração no build. As futuras alterações exigirão gerar e enviar a pasta `dist` novamente.

## 3. Instalar o conector no Linux ou Mac

Instale **Docker com Compose** e **Node.js 22**. No Linux, use Docker Engine; no Mac, Docker Desktop ou uma instalação Docker compatível. Mantenha o Docker iniciado.

No terminal, dentro deste checkout:

```bash
cd deploy/local-whatsapp
node init.mjs
```

O comando cria `.env` com permissão restrita e senhas aleatórias locais. Se o arquivo já existe, ele é preservado. Abra esse arquivo em um editor e preencha:

| Campo | Onde obter |
| --- | --- |
| `SUPABASE_URL` | URL HTTPS do projeto Supabase |
| `SUPABASE_SERVICE_ROLE_KEY` | Chave **legada service_role (JWT)** em Project Settings → API Keys |
| `ORGANIZATION_ID` | No CRM, Integrações → WhatsApp → Configurar conector no meu computador |

Preserve as senhas `POSTGRES_PASSWORD` e `EVOLUTION_API_KEY` geradas. A chave service_role tem privilégios elevados: use somente nesse computador confiável, nunca no frontend, no Git ou no chat. O arquivo `.env` é ignorado pelo Git e excluído do contexto da imagem Docker.

Inicie:

```bash
docker compose up -d --build
docker compose ps
```

A primeira instalação baixa as imagens e prepara os bancos. A Evolution usa uma imagem oficial fixada; há suporte a Linux x64 e ARM64, incluindo Macs Apple Silicon. Os bancos e as sessões ficam em volumes locais. PostgreSQL e Redis não têm portas públicas; a API Evolution fica limitada ao próprio computador.

## 4. Conectar e testar no CRM

1. Abra **Configurações → Integrações → WhatsApp por QR code**.
2. Como administrador, clique em **Gerar novo QR code**. O pedido vai ao computador e o QR aparece no próprio CRM em alguns segundos.
3. No celular, abra **WhatsApp → Dispositivos conectados** e escaneie. Aguarde **Conectada**.
4. Ative os avisos do workspace.
5. Cada pessoa salva seu próprio número com país e DDD e marca a autorização.
6. Crie uma atividade ou troque seu responsável. O conector consulta a fila a cada 15 segundos, com até três avisos por lote. Use **Atualizar envios** para conferir.

O site continua acessível quando o computador está desligado, mas o QR e os envios param. O conector preserva as mensagens na fila enquanto o WhatsApp estiver desconectado e, quando volta, confere responsável, autorização e conclusão antes de enviar. Não há envio automático para atribuições anteriores à ativação.

## 5. Interromper cobranças do Railway

Estes arquivos **não desligam sua conta Railway**. O serviço antigo pode continuar gerando consumo.

Depois de validar o novo site, exportar os dados necessários e confirmar que o CRM usa o Supabase correto:

1. Confira o backup e a nova publicação.
2. No Railway, remova os serviços antigos que você não utilizará e os volumes associados, somente após preservar os dados.
3. Confira **Usage/Billing** e cancele assinaturas pagas que não desejar manter.

Consumo anterior pode aparecer na fatura mesmo após a remoção. Deixar apenas o site sem acessos ou pausar parte dos recursos não garante que a cobrança pare. Não é necessário criar os serviços do guia Railway para usar este modo local.

## Operação e diagnóstico

`docker compose logs --tail=50 connector` mostra erros genéricos, sem imprimir chaves. Se o CRM indicar computador desligado, confira Docker, internet, identificador do workspace, modo `bridge` e migrations.

`docker compose stop` interrompe os serviços preservando os dados. `docker compose up -d` inicia novamente. Evite comandos com `--volumes` ou `-v` ao remover containers: apagar volumes elimina dados e sessões.

Desative a suspensão automática enquanto quiser receber avisos. Faça backup dos volumes antes de trocar de computador. Para atualizar a chave do Supabase, edite `.env` e execute `docker compose up -d`.

Os planos gratuitos têm quotas e podem mudar. Este preparo não publica o site, não aplica migrations no seu projeto e não confirma um pareamento real. Um teste com seu telefone continua necessário.

## Verificações locais do código

```bash
node deploy/local-whatsapp/bridge-check.mjs
npm test
npm run build
```
