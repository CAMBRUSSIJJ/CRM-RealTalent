import { test } from 'node:test'
import assert from 'node:assert/strict'
import { createBridge, safeQr } from './bridge.mjs'

const org = '00000000-0000-0000-0000-000000000001'
const image = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg=='
const config = { SUPABASE_URL: 'https://testproject.supabase.co', SUPABASE_SERVICE_ROLE_KEY: 'test-only-service-key',
  ORGANIZATION_ID: org, EVOLUTION_API_URL: 'http://evolution:8080', EVOLUTION_API_KEY: 'test-only-evolution-key-'.repeat(2) }
function fixture({ state = 'open', assigned = 'seller', consent = true, task = true, action, failSend = false } = {}) {
  const calls = []
  const responses = {
    activities: [{ assigned_to: assigned, completed_at: null }],
    task_whatsapp_preferences: [{ enabled: consent, phone: '5511999999999' }],
    task_whatsapp_settings: [{ enabled: true }],
    organization_members: [{ user_id: 'seller' }],
  }
  const fetcher = async (address, options) => {
    const url = new URL(address)
    const body = options.body && JSON.parse(options.body)
    calls.push({ url, ...options, body })
    const json = value => new Response(JSON.stringify(value))
    if (url.hostname === 'evolution') {
      if (url.pathname.includes('connectionState')) return state === 'missing' ? new Response('{}', { status: 404 }) : json({ instance: { state } })
      if (url.pathname === '/instance/create') return json({ qrcode: { base64: image }, hash: 'secret-not-returned' })
      if (url.pathname.includes('/instance/connect/')) return json({ base64: image })
      if (url.pathname.includes('/instance/logout/')) return json({ status: 'SUCCESS' })
      if (url.pathname.includes('/message/sendText/')) { if (failSend) throw new Error('timeout with sensitive payload'); return json({ key: { id: 'message-1' } }) }
    }
    if (url.pathname.endsWith('/rpc/claim_whatsapp_bridge_action')) return json(action ? [{ organization_id: org, requested_action: action, request_id: 'request-1' }] : [])
    if (url.pathname.endsWith('/rpc/claim_local_whatsapp_batch')) return json(task ? [{
      id: 'job', organization_id: org, activity_id: 'task', user_id: 'seller', recipient: '5511999999999', body: 'Tarefa atribuída', attempts: 1,
    }] : [])
    if (options.method === 'PATCH' || options.method === 'POST') return new Response(null, { status: 204 })
    const table = url.pathname.split('/').at(-1)
    if (responses[table]) return json(responses[table])
    throw new Error('Unexpected request: ' + url.pathname)
  }
  return { calls, bridge: createBridge(config, { fetcher, now: () => 100000 }) }
}
test('rejects public plain HTTP endpoints and invalid workspace', () => {
  assert.throws(() => createBridge({ ...config, SUPABASE_URL: 'http://public.example.com' }), /HTTPS/)
  assert.throws(() => createBridge({ ...config, EVOLUTION_API_URL: 'http://public.example.com' }), /rede interna/)
  assert.throws(() => createBridge({ ...config, ORGANIZATION_ID: '../another-workspace' }), /ORGANIZATION_ID/)
})
test('heartbeat uses an outbound Supabase request and server time, without public Evolution URL', async () => {
  const { bridge, calls } = fixture({ state: 'missing' })
  await bridge.pulse()
  const heartbeat = calls.find(call => call.url.pathname.endsWith('/whatsapp_local_bridge'))
  assert.equal(heartbeat.body.heartbeat_at, 'now')
  assert.equal(heartbeat.body.connection_state, 'missing')
  assert.ok(calls.every(call => ['testproject.supabase.co', 'evolution'].includes(call.url.hostname)))
  assert.ok(calls.every(call => call.redirect === 'error'))
})
test('connect request creates an instance and returns its inline QR to the private bridge row', async () => {
  const { bridge, calls } = fixture({ state: 'missing', action: 'connect' })
  await bridge.commands()
  const update = calls.find(call => call.method === 'PATCH')
  assert.equal(update.body.qr_base64, image)
  assert.equal(update.body.requested_action, null)
  assert.equal(update.url.searchParams.get('request_id'), 'eq.request-1')
  assert.ok(!JSON.stringify(update.body).includes('secret-not-returned'))
})
test('an open session clears the pairing image instead of generating another QR', async () => {
  const { bridge, calls } = fixture({ action: 'connect' })
  await bridge.commands()
  assert.equal(calls.find(call => call.method === 'PATCH').body.connection_state, 'open')
  assert.ok(!calls.some(call => call.url.pathname === '/instance/create'))
})
test('disconnect request logs out the workspace instance', async () => {
  const { bridge, calls } = fixture({ action: 'disconnect' })
  await bridge.commands()
  assert.ok(calls.some(call => call.method === 'DELETE' && call.url.pathname.endsWith('/realtalent-' + org)))
})
test('offline phone does not consume delivery attempts', async () => {
  const { bridge, calls } = fixture({ state: 'close' })
  assert.equal(await bridge.tasks(), 0)
  assert.ok(!calls.some(call => call.url.pathname.includes('claim_local_whatsapp_batch')))
})
for (const options of [{ assigned: 'other' }, { consent: false }]) test('changed assignee or consent cancels the pending delivery: ' + JSON.stringify(options), async () => {
  const { bridge, calls } = fixture(options)
  await bridge.tasks()
  assert.equal(calls.find(call => call.method === 'PATCH').body.status, 'cancelled')
  assert.ok(!calls.some(call => call.url.pathname.includes('sendText')))
})
test('valid assignment sends through the internal API and records its provider ID', async () => {
  const { bridge, calls } = fixture()
  await bridge.tasks()
  const claim = calls.find(call => call.url.pathname.includes('claim_local_whatsapp_batch'))
  assert.equal(claim.body.p_organization_id, org)
  assert.equal(calls.find(call => call.method === 'PATCH').body.external_message_id, 'message-1')
  assert.deepEqual(calls.find(call => call.url.pathname.includes('sendText')).body, { number: '5511999999999', text: 'Tarefa atribuída' })
})
test('uncertain send requires review and does not expose upstream error contents', async () => {
  const { bridge, calls } = fixture({ failSend: true })
  await bridge.tasks()
  const result = calls.find(call => call.method === 'PATCH').body
  assert.equal(result.status, 'dead_letter')
  assert.ok(!result.last_error.includes('sensitive'))
})
test('QR tokens and external image URLs are never accepted', () => {
  assert.equal(safeQr(image), image)
  for (const value of ['secret-pairing-token', 'https://example.com/qr', 'data:image/svg+xml;base64,abc']) assert.equal(safeQr(value), null)
})
