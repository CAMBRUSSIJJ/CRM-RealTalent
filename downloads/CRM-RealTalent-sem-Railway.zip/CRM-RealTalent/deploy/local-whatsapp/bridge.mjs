import { pathToFileURL } from 'node:url'
import { setTimeout as delay } from 'node:timers/promises'

export class ServiceError extends Error {
  constructor(service, status) {
    super(service + ' indisponível (HTTP ' + status + '). Confira o serviço e as credenciais locais.')
    this.service = service
    this.status = status
  }
}
export function safeQr(value) {
  if (typeof value !== 'string' || value.length > 500000) return null
  const raw = value.replace(/^data:image\/png;base64,/, '')
  return /^iVBORw0KGgo[A-Za-z0-9+/=\r\n]+$/.test(raw) ? 'data:image/png;base64,' + raw : null
}

export function createBridge(config, { fetcher = fetch, now = Date.now } = {}) {
  const organization = config.ORGANIZATION_ID || ''
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(organization)) throw new Error('Configure ORGANIZATION_ID com o identificador do workspace no CRM.')
  const supabase = new URL(config.SUPABASE_URL)
  const evolution = new URL(config.EVOLUTION_API_URL || 'http://evolution:8080')
  if (supabase.protocol !== 'https:' || supabase.username || supabase.password || supabase.search || supabase.hash || supabase.pathname !== '/') throw new Error('SUPABASE_URL deve ser a URL HTTPS do projeto.')
  const internal = ['evolution', 'localhost', '127.0.0.1'].includes(evolution.hostname)
  if ((evolution.protocol !== 'https:' && !(evolution.protocol === 'http:' && internal)) || evolution.username || evolution.password || evolution.search || evolution.hash || evolution.pathname !== '/') throw new Error('Evolution deve usar HTTPS ou a rede interna local.')
  if (!config.SUPABASE_SERVICE_ROLE_KEY || (config.EVOLUTION_API_KEY || '').length < 32) throw new Error('Configure as chaves somente no arquivo .env local.')
  const instance = 'realtalent-' + organization.toLowerCase()
  const filters = values => new URLSearchParams(values).toString()
  const orgFilter = { organization_id: 'eq.' + organization }

  async function call(service, path, method = 'GET', body, prefer) {
    const headers = service === 'Supabase'
      ? { apikey: config.SUPABASE_SERVICE_ROLE_KEY, authorization: 'Bearer ' + config.SUPABASE_SERVICE_ROLE_KEY }
      : { apikey: config.EVOLUTION_API_KEY }
    headers['content-type'] = 'application/json'
    if (prefer) headers.prefer = prefer
    const base = service === 'Supabase' ? supabase.origin : evolution.origin
    const response = await fetcher(base + path, {
      method, headers, redirect: 'error', signal: AbortSignal.timeout(15000),
      body: body === undefined ? undefined : JSON.stringify(body),
    })
    if (!response.ok) throw new ServiceError(service, response.status)
    if (response.status === 204 || prefer?.includes('return=minimal')) return null
    return await response.json()
  }
  const evo = (path, method, body) => call('Evolution', path, method, body)
  const rpc = (name, body) => call('Supabase', '/rest/v1/rpc/' + name, 'POST', body)
  const patch = (table, where, body) => call('Supabase', '/rest/v1/' + table + '?' + filters(where), 'PATCH', body, 'return=minimal')
  const one = async (table, where, select) => (await call('Supabase', '/rest/v1/' + table + '?' + filters({ select, ...where, limit: '1' })))[0]
  async function connection() {
    try { return (await evo('/instance/connectionState/' + instance)).instance?.state || 'close' }
    catch (error) { if (error instanceof ServiceError && error.status === 404) return 'missing'; throw error }
  }
  async function pulse() {
    const state = await connection()
    const value = { organization_id: organization, heartbeat_at: 'now', connection_state: state }
    if (state === 'open') Object.assign(value, { qr_base64: null, qr_expires_at: null, last_error: null })
    await call('Supabase', '/rest/v1/whatsapp_local_bridge?on_conflict=organization_id', 'POST', value, 'resolution=merge-duplicates,return=minimal')
    return state
  }
  async function commands() {
    const requests = await rpc('claim_whatsapp_bridge_action', { p_organization_id: organization })
    for (const request of requests || []) {
      if (request.organization_id !== organization) throw new Error('Workspace do pedido não corresponde ao conector.')
      let value
      try {
        if (request.requested_action === 'disconnect') {
          const state = await connection()
          if (state !== 'missing' && state !== 'close') await evo('/instance/logout/' + instance, 'DELETE')
          value = { connection_state: 'close', qr_base64: null, qr_expires_at: null, last_error: null }
        } else if (request.requested_action === 'connect') {
          let state = await connection()
          let image = null
          if (state === 'missing') {
            try {
              const result = await evo('/instance/create', 'POST', { instanceName: instance, integration: 'WHATSAPP-BAILEYS', qrcode: true })
              image = safeQr(result.qrcode?.base64 || result.base64)
            } catch (error) {
              if (!(error instanceof ServiceError) || ![403, 409].includes(error.status)) throw error
              state = await connection()
              if (state === 'missing') throw error
            }
          }
          if (state === 'open') value = { connection_state: 'open', qr_base64: null, qr_expires_at: null, last_error: null }
          else {
            if (!image) {
              const result = await evo('/instance/connect/' + instance)
              image = safeQr(result.base64 || result.qrcode?.base64)
            }
            value = { connection_state: 'connecting', qr_base64: image, qr_expires_at: image ? new Date(now() + 40000).toISOString() : null,
              last_error: image ? null : 'Aguarde o WhatsApp preparar o código e tente gerar novamente.' }
          }
        } else throw new Error('Ação inválida.')
      } catch {
        value = { connection_state: 'error', qr_base64: null, qr_expires_at: null,
          last_error: 'O conector não conseguiu operar a Evolution. Confira os serviços no computador e gere outro código.' }
      }
      await patch('whatsapp_local_bridge', { ...orgFilter, request_id: 'eq.' + request.request_id },
        { ...value, completed_request_id: request.request_id, requested_action: null, heartbeat_at: 'now' })
    }
    return requests?.length || 0
  }
  async function tasks() {
    // Keep queued tasks intact while the phone or the local Evolution is offline.
    if (await connection() !== 'open') return 0
    const items = await rpc('claim_local_whatsapp_batch', { p_organization_id: organization })
    for (const item of items || []) {
      if (item.organization_id !== organization) throw new Error('Workspace da tarefa não corresponde ao conector.')
      const where = { ...orgFilter, id: 'eq.' + item.id }
      let sending = false
      try {
        const [activity, preference, settings, member] = await Promise.all([
          one('activities', { ...orgFilter, id: 'eq.' + item.activity_id }, 'assigned_to,completed_at'),
          one('task_whatsapp_preferences', { ...orgFilter, user_id: 'eq.' + item.user_id }, 'enabled,phone'),
          one('task_whatsapp_settings', orgFilter, 'enabled'),
          one('organization_members', { ...orgFilter, user_id: 'eq.' + item.user_id }, 'user_id'),
        ])
        if (!member || !settings?.enabled || !preference?.enabled || preference.phone !== item.recipient ||
          activity?.assigned_to !== item.user_id || activity?.completed_at) {
          await patch('task_whatsapp_outbox', where, { status: 'cancelled', locked_at: null })
          continue
        }
        sending = true
        const result = await evo('/message/sendText/' + instance, 'POST', { number: item.recipient, text: item.body })
        if (!result.key?.id) throw new Error('Resultado de entrega incerto.')
        await patch('task_whatsapp_outbox', where, { status: 'sent', external_message_id: result.key.id, locked_at: null, last_error: null })
      } catch (error) {
        const uncertain = sending && (!(error instanceof ServiceError) || error.service !== 'Evolution' || error.status >= 500)
        const retryable = !uncertain && (!(error instanceof ServiceError) || error.status === 429 || error.status >= 500)
        await patch('task_whatsapp_outbox', where, {
          status: !retryable || item.attempts >= 5 ? 'dead_letter' : 'retry', locked_at: null,
          available_at: new Date(now() + Math.min(3600, 30 * 2 ** item.attempts) * 1000).toISOString(),
          last_error: uncertain ? 'Entrega incerta. Confira o WhatsApp antes de reenviar.'
            : 'Envio indisponível. Confira a Evolution e as credenciais do conector local.',
        })
      }
    }
    return items?.length || 0
  }
  return { pulse, commands, tasks }
}

async function main() {
  const bridge = createBridge(process.env)
  const stop = new AbortController()
  for (const signal of ['SIGTERM', 'SIGINT']) process.on(signal, () => stop.abort())
  async function loop(operation, interval) {
    while (!stop.signal.aborted) {
      try { await operation() } catch { console.error('Conector: serviço indisponível. Confira a configuração local; nenhuma chave é registrada neste log.') }
      try { await delay(interval, undefined, { signal: stop.signal }) } catch { break }
    }
  }
  console.log('Conector local iniciado. Mantenha este computador ligado para operar o WhatsApp.')
  await Promise.all([loop(bridge.pulse, 10000), loop(bridge.commands, 3000), loop(bridge.tasks, 15000)])
}
if (process.argv[1] && import.meta.url === pathToFileURL(process.argv[1]).href) {
  main().catch(() => { console.error('Configure o arquivo .env local conforme o guia. Nenhuma credencial deve ser enviada pelo chat.'); process.exitCode = 1 })
}
