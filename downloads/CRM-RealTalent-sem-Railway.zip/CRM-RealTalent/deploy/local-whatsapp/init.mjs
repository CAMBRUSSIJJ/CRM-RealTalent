import { randomBytes } from 'node:crypto'
import { writeFile } from 'node:fs/promises'
import { fileURLToPath } from 'node:url'
const file = new URL('./.env', import.meta.url)
try {
  await writeFile(file, [
    '# Somente no computador do conector. Nunca envie este arquivo ao Git ou ao chat.',
    'POSTGRES_PASSWORD=' + randomBytes(32).toString('hex'),
    'EVOLUTION_API_KEY=' + randomBytes(32).toString('hex'),
    'SUPABASE_URL=',
    '# Chave legada service_role (JWT) do projeto Supabase, nunca a chave pública.',
    'SUPABASE_SERVICE_ROLE_KEY=',
    'ORGANIZATION_ID=',
    '',
  ].join('\n'), { flag: 'wx', mode: 0o600 })
  console.log('Arquivo local criado: ' + fileURLToPath(file))
  console.log('Preencha SUPABASE_URL, SUPABASE_SERVICE_ROLE_KEY e ORGANIZATION_ID. As senhas locais já foram geradas e não são exibidas.')
} catch (error) {
  console.error(error.code === 'EEXIST' ? '.env já existe e foi preservado. Edite somente os campos necessários.' : 'Não foi possível criar o arquivo .env.')
  process.exitCode = 1
}
