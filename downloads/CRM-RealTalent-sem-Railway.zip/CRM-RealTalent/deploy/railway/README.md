# Ativar o WhatsApp no Railway

O CRM continua no serviço atual. Crie um serviço separado para a **Evolution API 2.3.7**, com PostgreSQL, Redis e volume persistente. A API pode ser usada sem tarifa por mensagem, mas o Railway cobra recursos conforme seu plano e consumo; não conte com hospedagem gratuita permanente.

## 1. Evolution no Railway

Depois de enviar estes arquivos ao GitHub:

1. Abra o projeto existente no Railway. Se já houver Evolution, confira a instalação existente antes de criar outra.
2. Adicione um **PostgreSQL** e um **Redis** pelos serviços de banco do Railway. Use os nomes **Postgres** e **Redis**. Eles devem ter seus volumes persistentes e permanecer na rede privada. Use bancos dedicados à Evolution, preservando o banco do CRM.
3. Adicione um serviço pelo mesmo repositório GitHub do CRM e nomeie-o **Evolution**. Em **Settings**, mantenha **Root Directory** na raiz do repositório (`/`) e use **Config File Path** `/deploy/railway/evolution/railway.toml`. O Dockerfile nesse caminho é exclusivo da Evolution.
4. Em **Variables → Raw Editor**, copie [evolution/variables.env.example](evolution/variables.env.example). Preserve as referências de variáveis; se seus serviços tiverem outros nomes, ajuste `Postgres` e `Redis`.
5. Preencha `AUTHENTICATION_API_KEY` com uma chave aleatória própria de pelo menos 32 caracteres, pelo painel. Um gerador de senhas serve. Guarde-a para configurar o Supabase; não a coloque no Git nem no frontend.
6. Adicione um **Volume** ao serviço Evolution com o caminho **`/evolution/instances`**. Use **uma réplica** e mantenha o serviço sempre ativo, com a opção de dormir/serverless desativada. A sessão do WhatsApp precisa sobreviver a reinícios.
7. Em **Networking → Generate Domain**, gere um domínio público HTTPS, com **target port 8080**. A variável `SERVER_URL` usa esse domínio. Não gere domínio público para os bancos.
8. Faça o deploy. Preserve o comando de início do Dockerfile: ele executa as migrations internas da Evolution e inicia a API. O healthcheck `/` deve retornar HTTP 200; isso confirma a API, ainda sem conectar um celular.

O projeto inclui imagem oficial fixada por versão e digest, porta e healthcheck. Volumes, bancos, domínio, réplica e modo sempre ativo precisam ser configurados no painel; o arquivo TOML não cria esses recursos.

Se preferir o serviço **Docker Image**, a imagem oficial é `evoapicloud/evolution-api:v2.3.7`. Use as mesmas variáveis, volume e porta, e substitua obrigatoriamente a chave de exemplo. O serviço pelo repositório usa ainda uma proteção que impede iniciar com a chave de exemplo ou sem a configuração necessária.

## 2. Conectar o Supabase

No projeto Supabase usado pelo CRM:

1. Aplique as migrations do repositório, incluindo `202611050001_task_assignment_whatsapp.sql`.
2. Em **Edge Functions → Secrets**, configure:

   | Nome | Valor |
   | --- | --- |
   | `WHATSAPP_CONNECTION_MODE` | `direct` para usar a Evolution hospedada no Railway |
   | `EVOLUTION_API_URL` | URL HTTPS pública do serviço Evolution, sem `/manager` |
   | `EVOLUTION_API_KEY` | A mesma chave `AUTHENTICATION_API_KEY` do Railway |
   | `WHATSAPP_TASK_WORKER_SECRET` | Outra chave aleatória, com pelo menos 32 caracteres |

3. Publique as funções `whatsapp-session` e `whatsapp-task-worker`. Pelo CLI Supabase já autenticado e vinculado ao projeto:

   ```bash
   supabase functions deploy whatsapp-session
   supabase functions deploy whatsapp-task-worker
   ```

4. Ative **Cron (pg_cron)**, **pg_net** e **Vault** no Dashboard Supabase. No Vault crie:

   | Nome | Valor |
   | --- | --- |
   | `realtalent_whatsapp_worker_url` | `https://<seu-projeto>.supabase.co/functions/v1/whatsapp-task-worker` |
   | `realtalent_whatsapp_worker_secret` | O mesmo `WHATSAPP_TASK_WORKER_SECRET` das funções |

5. Execute [../supabase/schedule-whatsapp.sql](../supabase/schedule-whatsapp.sql) no SQL Editor. Ele valida os requisitos e agenda a fila a cada minuto, sem chave gravada no código. Executar novamente atualiza o job do mesmo usuário. Use esse agendador ou outro que já exista, evitando agendamentos duplicados.

O agendamento roda no Supabase; não é necessário um segundo serviço Railway só para despachar notificações. O serviço Evolution deve continuar ativo.

## 3. CRM e primeiro teste

No serviço Railway do **CRM**, confira `VITE_DATA_MODE=supabase`, `VITE_SUPABASE_URL` e `VITE_SUPABASE_PUBLISHABLE_KEY`. Essas variáveis precisam existir no build do frontend. Faça novo deploy do CRM com as alterações; os segredos da Evolution ficam somente nas funções Supabase.

Como administrador, acesse **Configurações → Integrações → WhatsApp por QR code**, gere o QR e escaneie pelo celular em **Dispositivos conectados**. Aguarde o estado **Conectada**. Ative os avisos do workspace.

Cada pessoa cadastra seu próprio número com país e DDD e marca a autorização. Crie uma atividade com esse responsável. O envio entra na fila e é processado nas próximas execuções do agendador; o intervalo é de um minuto e o lote é de até três avisos por execução. Em **Atualizar envios**, confira o resultado. Aceitação pela API não confirma leitura.

Para validar a persistência, reinicie somente o serviço Evolution após o primeiro pareamento e confirme o estado novamente no CRM. Não remova os volumes.

## Se não conectar

- **Serviço não inicia:** confira as referências de PostgreSQL/Redis, o volume, a chave e os logs do deploy. Não cole logs com credenciais no chat.
- **404 na função:** publique `whatsapp-session` no projeto Supabase configurado no CRM.
- **Credencial recusada:** a chave nas funções deve coincidir com a do serviço Evolution.
- **QR não aparece:** espere a API ficar saudável, confira se o domínio aponta à porta 8080 e gere um novo código. Um healthcheck positivo não valida o pareamento.
- **Conectou, mas não avisou:** confira consentimento, avisos ativos, execução do Cron e estado da fila. Ativar avisos não envia atribuições antigas.

Esta preparação não cria recursos na sua conta, não altera produção e não confirma um pareamento real.
