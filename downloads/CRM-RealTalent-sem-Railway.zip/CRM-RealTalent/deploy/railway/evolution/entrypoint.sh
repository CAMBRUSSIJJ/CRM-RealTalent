#!/bin/sh
set -eu

# Refuse the upstream example key before the image loads its bundled .env.
api_key="${AUTHENTICATION_API_KEY:-}"
if [ "${#api_key}" -lt 32 ]; then
  echo "Configure AUTHENTICATION_API_KEY com pelo menos 32 caracteres nas Variables do Railway." >&2
  exit 1
fi
if [ "$api_key" = "429683C4C977415CAAFCCE10F7D57E11" ]; then
  echo "Substitua a chave de exemplo da Evolution por uma chave aleatória própria." >&2
  exit 1
fi
: "${DATABASE_CONNECTION_URI:?Configure a referência Postgres.DATABASE_URL no Railway}"
: "${CACHE_REDIS_URI:?Configure a referência Redis.REDIS_URL no Railway}"
: "${SERVER_URL:?Configure a URL HTTPS pública da Evolution}"

cd /evolution
# Preserve the official image's migration and startup flow.
exec /bin/bash -c '. ./Docker/scripts/deploy_database.sh && exec npm run start:prod'
