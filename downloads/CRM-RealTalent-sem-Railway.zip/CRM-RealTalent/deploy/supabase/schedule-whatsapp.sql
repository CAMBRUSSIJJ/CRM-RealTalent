-- Run in your Supabase SQL Editor after deploying the functions.
-- Enable Cron (pg_cron), pg_net and Vault in the Dashboard first.
-- In Vault create exactly one secret for each name:
-- realtalent_whatsapp_worker_url = https://<project>.supabase.co/functions/v1/whatsapp-task-worker
-- realtalent_whatsapp_worker_secret = same value as WHATSAPP_TASK_WORKER_SECRET in Edge Function Secrets
-- Values belong in Vault, never in this versioned script.
begin;
do $check$
declare
  worker_url text;
  worker_secret text;
begin
  if to_regclass('cron.job') is null then raise exception 'Ative Cron (pg_cron) no Dashboard Supabase.'; end if;
  if to_regclass('vault.decrypted_secrets') is null then raise exception 'Ative Vault no Dashboard Supabase.'; end if;
  if not exists(select 1 from pg_extension where extname='pg_net') then raise exception 'Ative pg_net no Dashboard Supabase.'; end if;
  if (select count(*) from vault.decrypted_secrets where name='realtalent_whatsapp_worker_url') <> 1
    or (select count(*) from vault.decrypted_secrets where name='realtalent_whatsapp_worker_secret') <> 1 then
    raise exception 'Crie um segredo Vault para a URL do worker e outro para o segredo do worker, sem nomes duplicados.';
  end if;
  select decrypted_secret into worker_url from vault.decrypted_secrets where name='realtalent_whatsapp_worker_url';
  select decrypted_secret into worker_secret from vault.decrypted_secrets where name='realtalent_whatsapp_worker_secret';
  if worker_url is null or worker_url !~ '^https://[a-z0-9-]+[.]supabase[.]co/functions/v1/whatsapp-task-worker$' then
    raise exception 'A URL no Vault deve apontar para whatsapp-task-worker no seu projeto Supabase.';
  end if;
  if worker_secret is null or length(worker_secret) < 32 then
    raise exception 'O segredo do worker no Vault deve ter pelo menos 32 caracteres.';
  end if;
end;
$check$;

-- pg_cron updates a job with this name for the same owner; rerunning does not duplicate it.
select cron.schedule(
  'realtalent-whatsapp-tasks',
  '* * * * *',
  $job$
    select net.http_post(
      url := (select decrypted_secret from vault.decrypted_secrets where name='realtalent_whatsapp_worker_url'),
      headers := jsonb_build_object(
        'Content-Type', 'application/json',
        'x-worker-secret', (select decrypted_secret from vault.decrypted_secrets where name='realtalent_whatsapp_worker_secret')
      ),
      body := '{}'::jsonb,
      timeout_milliseconds := 120000
    );
  $job$
);
commit;

select jobid,jobname,schedule,active from cron.job where jobname='realtalent-whatsapp-tasks';
