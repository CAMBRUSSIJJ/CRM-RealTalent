import { Save, Trash2 } from 'lucide-react'
import { useEffect, useState } from 'react'
import { useApp } from '../../app/app-context'
import { Button } from '../../components/ui/button'
import { Modal } from '../../components/ui/modal'
import type { ActivityItem, ActivityType, WorkspaceMember } from '../../domain/types'
import { appendFollowupMetadata, readFollowupMetadata, stripFollowupMetadata } from '../../services/followup-workspace'

const toInputDateTime = (value: string | null) => {
  if (!value) return ''
  const date = new Date(value)
  const local = new Date(date.getTime() - date.getTimezoneOffset() * 60000)
  return local.toISOString().slice(0, 16)
}

interface Props {
  open: boolean
  activity?: ActivityItem | null
  initialLeadId?: string
  initialType?: ActivityType
  initialTitle?: string
  onClose(): void
}

export function ActivityModal({ open, activity, initialLeadId = '', initialType = 'followup', initialTitle = '', onClose }: Props) {
  const { snapshot, currentWorkspace, repositoryMode, listWorkspaceMembers, createActivity, updateActivity, deleteActivity, notify, confirmAction } = useApp()
  const [members, setMembers] = useState<WorkspaceMember[]>([])
  const [assignedTo, setAssignedTo] = useState('')
  const [membersLoading, setMembersLoading] = useState(false)

  useEffect(() => {
    if (!open) return
    let active = true
    setMembers([])
    setMembersLoading(true)
    void listWorkspaceMembers().then((items) => { if (active) setMembers(items) })
      .catch(() => { if (active) notify('error', 'Não foi possível carregar os responsáveis. Feche e abra a atividade para tentar novamente.') })
      .finally(() => { if (active) setMembersLoading(false) })
    return () => { active = false }
  }, [open, currentWorkspace?.id])
  const [leadId, setLeadId] = useState('')
  const [type, setType] = useState<ActivityType>('followup')
  const [title, setTitle] = useState('')
  const [description, setDescription] = useState('')
  const [dueAt, setDueAt] = useState('')
  const [busy, setBusy] = useState(false)

  useEffect(() => {
    if (!open) return
    setLeadId(activity?.leadId ?? initialLeadId)
    setType(activity?.type ?? initialType)
    setTitle(activity?.title ?? initialTitle)
    setDescription(stripFollowupMetadata(activity?.description ?? ''))
    setDueAt(toInputDateTime(activity?.dueAt ?? null))
    setAssignedTo(activity?.assignedTo ?? snapshot?.leads.find((lead) => lead.id === initialLeadId)?.ownerId ?? '')
  }, [activity, initialLeadId, initialTitle, initialType, open])

  const submit = async () => {
    if (!title.trim()) { notify('error', 'Informe o título da atividade.'); return }
    if (['followup', 'meeting', 'call'].includes(type) && !dueAt) { notify('error', 'Informe a data e o horário.'); return }
    setBusy(true)
    try {
      const payload = {
        leadId: leadId || null,
        type,
        title: title.trim(),
        description: activity && readFollowupMetadata(activity) ? appendFollowupMetadata(description.trim(), readFollowupMetadata(activity)!) : description.trim(),
        dueAt: dueAt ? new Date(dueAt).toISOString() : null,
        completedAt: activity?.completedAt ?? null,
        assignedTo: assignedTo || null,
      }
      if (activity) await updateActivity(activity.id, payload)
      else await createActivity(payload)
      onClose()
    } catch (error) { notify('error', error instanceof Error ? error.message : 'Não foi possível salvar a atividade.') }
    finally { setBusy(false) }
  }

  const remove = async () => {
    if (!activity) return
    if (!await confirmAction({ title: 'Excluir atividade?', description: 'Esta atividade será removida da fila e do histórico operacional.', confirmLabel: 'Excluir atividade', tone: 'danger' })) return
    setBusy(true)
    try { await deleteActivity(activity.id); onClose() }
    catch (error) { notify('error', error instanceof Error ? error.message : 'Não foi possível excluir.') }
    finally { setBusy(false) }
  }

  const locked = Boolean(activity && activity.sourceType !== 'manual')

  return <Modal open={open} onClose={onClose} title={activity ? 'Editar atividade' : 'Nova atividade'} subtitle={locked ? 'Esta atividade é sincronizada pelo módulo de origem.' : 'Vincule o próximo passo ao lead e à fila diária.'} footer={
    <>
      {activity && !locked ? <Button variant="danger" disabled={busy} onClick={() => void remove()}><Trash2 size={16} /> Excluir</Button> : null}
      <span className="modal__footer-spacer" />
      <Button variant="secondary" onClick={onClose}>Cancelar</Button>
      <Button loading={busy} disabled={locked} onClick={() => void submit()}><Save size={16} /> Salvar</Button>
    </>
  }>
    <div className="form-grid">
      <label className="field field--span-2"><span>Lead relacionado</span><select value={leadId} onChange={(event) => setLeadId(event.target.value)} disabled={locked}><option value="">Sem lead</option>{snapshot?.leads.filter((lead) => lead.status === 'active').map((lead) => <option key={lead.id} value={lead.id}>{lead.name}</option>)}</select></label>
      <label className="field"><span>Tipo</span><select value={type} onChange={(event) => setType(event.target.value as ActivityType)} disabled={locked}><option value="followup">Follow-up</option><option value="call">Ligação programada</option><option value="meeting">Reunião</option><option value="note">Nota</option></select></label>
      <label className="field"><span>Data e horário</span><input type="datetime-local" value={dueAt} onChange={(event) => setDueAt(event.target.value)} disabled={locked} /></label>
      <label className="field field--span-2"><span>Responsável</span><select aria-label="Responsável" value={assignedTo} onChange={(event) => setAssignedTo(event.target.value)} disabled={locked || membersLoading}><option value="">Sem responsável</option>{assignedTo && !members.some((member) => member.userId === assignedTo) ? <option value={assignedTo}>Responsável atual</option> : null}{members.filter((member) => member.role !== 'viewer' || member.userId === assignedTo).map((member) => <option key={member.userId} value={member.userId}>{member.displayName || member.email}</option>)}</select><small>{repositoryMode === 'supabase' ? 'O envio de avisos pelo WhatsApp exige configuração em Integrações.' : 'No modo local, a atribuição fica neste navegador e não envia mensagens.'}</small></label>
      <label className="field field--span-2"><span>Título</span><input value={title} onChange={(event) => setTitle(event.target.value)} maxLength={240} disabled={locked} placeholder="Ex.: Retomar proposta enviada" /></label>
      <label className="field field--span-2"><span>Orientação</span><textarea rows={4} value={description} onChange={(event) => setDescription(event.target.value)} disabled={locked} placeholder="Contexto e objetivo do próximo contato" /></label>
    </div>
  </Modal>
}
