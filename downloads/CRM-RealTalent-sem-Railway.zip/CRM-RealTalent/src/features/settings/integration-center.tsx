import type { WorkspaceMember } from '../../domain/types'
import type { CrmPreferences } from './preferences-context'
import { IntegrationFrameworkPanel } from './integration-framework-panel'
import { WhatsAppPanel } from './whatsapp-panel'

interface IntegrationCenterProps {
  preferences: CrmPreferences['integrations']
  members: WorkspaceMember[]
  onPreferencesChange(patch: Partial<CrmPreferences['integrations']>): void
}

export function IntegrationCenter(props: IntegrationCenterProps) {
  return <div className="page-stack"><WhatsAppPanel /><IntegrationFrameworkPanel {...props} /></div>
}
