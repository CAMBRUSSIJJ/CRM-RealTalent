import { useEffect, useRef, useState } from 'react'
import { useApp } from '../../app/app-context'
import { Button } from '../../components/ui/button'
import { loadTaskWhatsAppSettings, saveTaskWhatsAppPreference, setTaskWhatsAppEnabled, whatsappSession, type TaskWhatsAppSettings } from '../../services/whatsapp-session'

const statusLabels: Record<string, string> = { queued: 'Na fila', processing: 'Enviando', sent: 'Enviado ao WhatsApp', retry: 'Nova tentativa programada', cancelled: 'Cancelado', dead_letter: 'Requer revisão' }
export function WhatsAppPanel() {
  const { currentWorkspace, repositoryMode, notify, confirmAction } = useApp()
  const organizationId = currentWorkspace?.id
  const canManage = currentWorkspace?.role === 'owner' || currentWorkspace?.role === 'admin'
  const [state, setState] = useState('unknown')
  const [qr, setQr] = useState<string | null>(null)
  const [settings, setSettings] = useState<TaskWhatsAppSettings | null>(null)
  const [phone, setPhone] = useState('')
  const [consent, setConsent] = useState(false)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')
  const [bridgeMessage, setBridgeMessage] = useState('')
  const generation = useRef(0)
  const qrDeadline = useRef(0)

  useEffect(() => {
    const version = ++generation.current
    setQr(null); setSettings(null); setState('unknown'); setPhone(''); setConsent(false); setError(''); setBridgeMessage(''); setBusy(false)
    if (!organizationId || repositoryMode !== 'supabase') return
    let polling = false
    let sessionError = false
    void loadTaskWhatsAppSettings(organizationId).then(value => {
      if (generation.current !== version) return
      setSettings(value); setPhone(value.preference?.phone || ''); setConsent(value.preference?.enabled || false)
    }).catch(e => { if (generation.current === version) setError(e.message) })
    const poll = async () => {
      if (polling) return
      polling = true
      try {
        const session = await whatsappSession(organizationId, 'status')
        if (generation.current !== version) return
        setState(session.state)
        if (sessionError) { setError(''); sessionError = false }
        if (session.connectionMode === 'bridge') {
          if (session.qr && session.expiresIn) {
            qrDeadline.current = Date.now() + session.expiresIn * 1000
            setQr(session.qr)
          } else setQr(null)
          setBridgeMessage(session.message || '')
        }
        if (session.state === 'open' || Date.now() >= qrDeadline.current) setQr(null)
      } catch (e) {
        if (generation.current === version) { sessionError = true; setState('error'); setQr(null); setError(e instanceof Error ? e.message : 'Não foi possível consultar o WhatsApp.') }
      } finally { polling = false }
    }
    void poll()
    const interval = window.setInterval(() => { void poll() }, 5000)
    return () => { generation.current++; window.clearInterval(interval) }
  }, [organizationId, repositoryMode])

  useEffect(() => {
    if (!qr) return
    const timeout = window.setTimeout(() => { setQr(null) }, Math.max(0, qrDeadline.current - Date.now()))
    return () => window.clearTimeout(timeout)
  }, [qr])

  const run = async (action: () => Promise<void>) => {
    const version = generation.current
    setBusy(true); setError('')
    try { await action() }
    catch (e) { if (version === generation.current) setError(e instanceof Error ? e.message : 'Operação indisponível.') }
    finally { if (version === generation.current) setBusy(false) }
  }
  const connect = () => run(async () => {
    if (!organizationId) return
    const version = generation.current
    setQr(null)
    const session = await whatsappSession(organizationId, 'connect')
    if (generation.current !== version) return
    setState(session.state)
    qrDeadline.current = Date.now() + (session.expiresIn || 40) * 1000
    setQr(session.qr)
    if (session.message) setError(session.message)
  })
  const local = repositoryMode !== 'supabase'
  return <article className="panel page-stack">
    <div className="panel__heading"><div><span className="eyebrow">WhatsApp por QR code</span><h3>Conexão e avisos de tarefas</h3></div></div>
    <p>Conecte um número do workspace pela Evolution API. Cada pessoa cadastra seu próprio número e autoriza os avisos de tarefas atribuídas.</p>
    {local ? <div className="warning-box">Disponível com Supabase e Evolution API configurados. O modo local não conecta números nem envia mensagens.</div> : <>
      <p role="status">Conexão: {state === 'open' ? 'Conectada' : state === 'connecting' ? 'Aguardando leitura do QR code' : state === 'offline' ? 'Computador do WhatsApp desligado ou conector parado' : state === 'unknown' ? 'Consultando...' : state === 'error' ? 'Serviço indisponível' : 'Desconectada'}</p>
      {canManage ? <details><summary>Configurar conector no meu computador</summary><p>Use este identificador no campo ORGANIZATION_ID do conector local:</p><code>{organizationId}</code><p>O conector precisa ficar ligado para gerar o QR e enviar avisos.</p></details> : null}
      {canManage ? <div className="settings-actions"><Button disabled={busy || state === 'open'} onClick={() => void connect()}>Gerar novo QR code</Button><Button variant="secondary" disabled={busy || state !== 'open'} onClick={() => void run(async () => {
        if (!organizationId || !await confirmAction({ title: 'Desconectar WhatsApp?', description: 'Os envios ficarão parados até conectar novamente.', confirmLabel: 'Desconectar' })) return
        const version = generation.current
        await whatsappSession(organizationId, 'disconnect')
        if (generation.current === version) { setState('close'); setQr(null) }
      })}>Desconectar</Button></div> : <p>Peça a um administrador para conectar o número do workspace.</p>}
      {qr ? <div><img src={qr} width={260} height={260} alt="QR code para conectar o WhatsApp do workspace" /><p>No WhatsApp, abra Dispositivos conectados e escaneie o código. Ele expira em até 40 segundos.</p></div> : state === 'connecting' ? <p>Se o código expirou, gere um novo QR code.</p> : null}
      {settings ? <>
        {canManage ? <label className="settings-toggle"><input type="checkbox" checked={settings.enabled} disabled={busy} onChange={e => {
          const enabled = e.target.checked
          void run(async () => { if (!organizationId) return; const version = generation.current; await setTaskWhatsAppEnabled(organizationId, enabled); if (generation.current === version) setSettings({ ...settings, enabled }) })
        }} /><span>Ativar avisos de atribuição neste workspace</span></label> : <p>Avisos do workspace: {settings.enabled ? 'Ativos' : 'Desativados'}</p>}
        <label className="field"><span>Meu número WhatsApp, com país e DDD</span><input type="tel" value={phone} onChange={e => setPhone(e.target.value)} placeholder="+55 11 99999-9999" /></label>
        <label className="settings-toggle"><input type="checkbox" checked={consent} onChange={e => setConsent(e.target.checked)} /><span>Autorizo receber neste número avisos das tarefas atribuídas a mim.</span></label>
        <div><Button disabled={busy} onClick={() => void run(async () => {
          if (!organizationId) return
          const version = generation.current
          await saveTaskWhatsAppPreference(organizationId, phone, consent)
          if (generation.current === version) notify('success', 'Preferência de WhatsApp salva.')
        })}>Salvar meu número e autorização</Button></div>
        <p>Os avisos são enviados nas novas atribuições e trocas de responsável. Alterar apenas o título ou o prazo não envia outro aviso.</p>
        {settings.recent.length ? <div><h4>Últimos envios</h4>{settings.recent.map(item => <p key={item.id}>{statusLabels[item.status] || item.status} · {item.attempts} tentativa(s){item.last_error ? ' — ' + item.last_error : ''}</p>)}</div> : null}
        <div><Button variant="secondary" disabled={busy} onClick={() => void run(async () => { if (!organizationId) return; const version = generation.current; const value = await loadTaskWhatsAppSettings(organizationId); if (generation.current === version) setSettings(value) })}>Atualizar envios</Button></div>
      </> : null}
    </>}
    {error || bridgeMessage ? <div className="warning-box" role="alert">{error || bridgeMessage}</div> : null}
  </article>
}
