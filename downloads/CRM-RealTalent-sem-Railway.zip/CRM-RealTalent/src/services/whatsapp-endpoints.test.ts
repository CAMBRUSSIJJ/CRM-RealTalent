import { readFileSync } from 'node:fs'
import ts from 'typescript'
import { afterEach, describe, expect, it, vi } from 'vitest'
import { createEvolution, EvolutionError, instanceName, qrImage } from '../../supabase/functions/_shared/evolution'

const org = '00000000-0000-0000-0000-000000000001'
const png = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUg=='
type Handler = (req: Request) => Promise<Response>
async function endpoint(name: string, client: unknown, extraEnv: Record<string, string> = {}) {
  let handler!: Handler
  const env = { SUPABASE_URL: 'https://supabase.example.com', SUPABASE_ANON_KEY: 'public', SUPABASE_SERVICE_ROLE_KEY: 'private', EVOLUTION_API_URL: 'https://evolution.example.com', EVOLUTION_API_KEY: 'server-key', WHATSAPP_TASK_WORKER_SECRET: 'x'.repeat(32), ...extraEnv }
  const source = readFileSync(new URL('../../supabase/functions/' + name + '/index.ts', import.meta.url), 'utf8').replace(/^import .*$/gm, '')
  const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ESNext } }).outputText
  const initialize = new Function('createClient', 'createEvolution', 'EvolutionError', 'instanceName', 'qrImage', 'Deno', js)
  initialize(() => client, createEvolution, EvolutionError, instanceName, qrImage, {
    env: { get: (key: keyof typeof env) => env[key] },
    serve: (fn: Handler) => { handler = fn },
  })
  return handler
}
const sessionClient = (role = 'admin', signedIn = true) => ({
  auth: { getUser: async () => ({ data: { user: signedIn ? { id: 'user' } : null } }) },
  from: () => {
    const chain = { select: () => chain, eq: () => chain, maybeSingle: async () => ({ data: { role }, error: null }) }
    return chain
  },
})
const request = (action: string) => new Request('https://edge.example.com', { method: 'POST', body: JSON.stringify({ organizationId: org, action }) })
const bridgeFixture = (role = 'admin', online = true) => {
  const base = sessionClient(role)
  const updates: Record<string, unknown>[] = []
  const row = { heartbeat_at: new Date(Date.now() - (online ? 1000 : 60000)).toISOString(),
    connection_state: 'connecting', qr_base64: png, qr_expires_at: new Date(Date.now() + 35000).toISOString() }
  return { row, updates, client: { ...base, from: (table: string) => {
    if (table === 'organization_members') return base.from()
    const chain = { select: () => chain, eq: () => chain, maybeSingle: async () => ({ data: row, error: null }),
      update: (value: Record<string, unknown>) => { updates.push(value); return chain },
      then: (resolve: (value: unknown) => unknown) => Promise.resolve({ error: null }).then(resolve) }
    return chain
  } } }
}
afterEach(() => vi.unstubAllGlobals())

describe('conector local sem servidor público', () => {
  const env = { WHATSAPP_CONNECTION_MODE: 'bridge', EVOLUTION_API_URL: '', EVOLUTION_API_KEY: '' }
  it('retorna QR privado do computador sem acessar uma Evolution pública', async () => {
    const f = bridgeFixture(); const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher)
    const response = await (await endpoint('whatsapp-session', f.client, env))(request('status'))
    expect(await response.json()).toMatchObject({ qr: png, connectionMode: 'bridge' })
    expect(fetcher).not.toHaveBeenCalled()
  })
  it('não expõe QR de pareamento a membros sem permissão de administrar', async () => {
    const f = bridgeFixture('member')
    const response = await (await endpoint('whatsapp-session', f.client, env))(request('status'))
    expect(await response.json()).toMatchObject({ qr: null })
  })
  it('oculta QR expirado e informa conector offline', async () => {
    const f = bridgeFixture(); f.row.qr_expires_at = new Date(Date.now() - 1000).toISOString()
    expect(await (await (await endpoint('whatsapp-session', f.client, env))(request('status'))).json()).toMatchObject({ qr: null })
    const offline = bridgeFixture('admin', false)
    expect(await (await (await endpoint('whatsapp-session', offline.client, env))(request('status'))).json()).toMatchObject({ state: 'offline', qr: null })
    expect((await (await endpoint('whatsapp-session', offline.client, env))(request('connect'))).status).toBe(503)
    expect(offline.updates).toHaveLength(0)
  })
  it('encaminha o pedido ao computador com um identificador de requisição', async () => {
    const f = bridgeFixture()
    const response = await (await endpoint('whatsapp-session', f.client, env))(request('connect'))
    expect(response.status).toBe(200)
    expect(f.updates[0]).toMatchObject({ requested_action: 'connect', request_id: expect.any(String), qr_base64: null })
  })
  it('não permite que o agendador da nuvem consuma a fila local', async () => {
    const client = { rpc: vi.fn() }
    const response = await (await endpoint('whatsapp-task-worker', client, env))(new Request('https://edge.example.com', { method: 'POST', headers: { 'x-worker-secret': 'x'.repeat(32) } }))
    expect(await response.json()).toMatchObject({ processed: 0, mode: 'bridge' })
    expect(client.rpc).not.toHaveBeenCalled()
  })
})

describe('endpoint do QR code', () => {
  it('bloqueia usuários sem sessão e conexão por quem não administra', async () => {
    const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher)
    expect((await (await endpoint('whatsapp-session', sessionClient('admin', false)))(request('connect'))).status).toBe(401)
    expect((await (await endpoint('whatsapp-session', sessionClient('member')))(request('connect'))).status).toBe(403)
    expect(fetcher).not.toHaveBeenCalled()
  })
  it('cria a instância ausente e retorna somente o QR inline e sua expiração', async () => {
    const fetcher = vi.fn()
      .mockResolvedValueOnce(new Response('{}', { status: 404 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ hash: 'never-expose-this' })))
      .mockResolvedValueOnce(new Response(JSON.stringify({ base64: png, code: 'never-expose-token' })))
    vi.stubGlobal('fetch', fetcher)
    const response = await (await endpoint('whatsapp-session', sessionClient()))(request('connect'))
    expect(response.status).toBe(200)
    const data = await response.json()
    expect(data).toMatchObject({ state: 'connecting', qr: png, expiresIn: 40 })
    expect(JSON.stringify(data)).not.toContain('never-expose')
    expect(fetcher.mock.calls[1][0]).toBe('https://evolution.example.com/instance/create')
  })
  it('não gera outro QR quando a conexão está aberta', async () => {
    const fetcher = vi.fn().mockResolvedValue(new Response(JSON.stringify({ instance: { state: 'open' } })))
    vi.stubGlobal('fetch', fetcher)
    expect(await (await (await endpoint('whatsapp-session', sessionClient()))(request('connect'))).json()).toEqual({ state: 'open', qr: null })
    expect(fetcher).toHaveBeenCalledTimes(1)
  })
  it('recupera a criação concorrente sinalizada com 403 pela Evolution 2.3.7', async () => {
    const fetcher = vi.fn()
      .mockResolvedValueOnce(new Response('{}', { status: 404 }))
      .mockResolvedValueOnce(new Response('{}', { status: 403 }))
      .mockResolvedValueOnce(new Response(JSON.stringify({ instance: { state: 'connecting' } })))
      .mockResolvedValueOnce(new Response(JSON.stringify({ base64: png })))
    vi.stubGlobal('fetch', fetcher)
    const response = await (await endpoint('whatsapp-session', sessionClient()))(request('connect'))
    expect(response.status).toBe(200)
    expect(await response.json()).toMatchObject({ qr: png })
  })
  it('não confunde uma chave recusada com instância criada por outra requisição', async () => {
    const fetcher = vi.fn()
      .mockResolvedValueOnce(new Response('{}', { status: 404 }))
      .mockResolvedValueOnce(new Response('{}', { status: 403 }))
      .mockResolvedValueOnce(new Response('{}', { status: 403 }))
    vi.stubGlobal('fetch', fetcher)
    const response = await (await endpoint('whatsapp-session', sessionClient()))(request('connect'))
    expect(response.status).toBe(502)
    expect(await response.json()).toMatchObject({ error: expect.stringContaining('Credencial') })
  })
  it('informa configuração ausente sem chamar o provedor', async () => {
    const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher)
    expect((await (await endpoint('whatsapp-session', sessionClient(), { EVOLUTION_API_KEY: '' }))(request('status'))).status).toBe(503)
    expect(fetcher).not.toHaveBeenCalled()
  })
})

describe('worker de atribuições', () => {
  const fixture = (assignedTo = 'seller', optedIn = true) => {
    const updates: Record<string, unknown>[] = []
    const data: Record<string, unknown> = {
      activities: { assigned_to: assignedTo, completed_at: null },
      task_whatsapp_preferences: { enabled: optedIn, phone: '5511999999999' },
      task_whatsapp_settings: { enabled: true },
      organization_members: { user_id: 'seller' },
    }
    const client = {
      rpc: async () => ({ data: [{ id: 'job', organization_id: org, activity_id: 'activity', user_id: 'seller', recipient: '5511999999999', body: 'Nova tarefa', attempts: 1 }], error: null }),
      from: (table: string) => {
        const chain = { select: () => chain, eq: () => chain, maybeSingle: async () => ({ data: data[table], error: null }),
          update: (value: Record<string, unknown>) => { updates.push(value); return chain },
          then: (resolve: (value: unknown) => unknown) => Promise.resolve({ error: null }).then(resolve) }
        return chain
      },
    }
    return { client, updates }
  }
  const workerRequest = () => new Request('https://edge.example.com', { method: 'POST', headers: { 'x-worker-secret': 'x'.repeat(32) } })
  it('não acessa a fila sem segredo do agendador', async () => {
    const f = fixture(); const handler = await endpoint('whatsapp-task-worker', f.client)
    expect((await handler(new Request('https://edge.example.com', { method: 'POST' }))).status).toBe(401)
  })
  it.each([['other-seller', true], ['seller', false]])('cancela destinatário desatualizado ou sem autorização: %s/%s', async (assignedTo, consent) => {
    const f = fixture(assignedTo, consent); const fetcher = vi.fn(); vi.stubGlobal('fetch', fetcher)
    await (await endpoint('whatsapp-task-worker', f.client))(workerRequest())
    expect(f.updates[0].status).toBe('cancelled')
    expect(fetcher).not.toHaveBeenCalled()
  })
  it('envia pela instância do workspace e registra o ID do serviço', async () => {
    const f = fixture()
    const fetcher = vi.fn().mockResolvedValueOnce(new Response(JSON.stringify({ instance: { state: 'open' } })))
      .mockResolvedValueOnce(new Response(JSON.stringify({ key: { id: 'message-id' } })))
    vi.stubGlobal('fetch', fetcher)
    await (await endpoint('whatsapp-task-worker', f.client))(workerRequest())
    expect(f.updates[0]).toMatchObject({ status: 'sent', external_message_id: 'message-id' })
    expect(fetcher.mock.calls[1][0]).toContain('/message/sendText/realtalent-' + org)
    expect(JSON.parse(fetcher.mock.calls[1][1].body)).toEqual({ number: '5511999999999', text: 'Nova tarefa' })
  })
  it('não reenvia automaticamente uma entrega incerta', async () => {
    const f = fixture()
    vi.stubGlobal('fetch', vi.fn().mockResolvedValueOnce(new Response(JSON.stringify({ instance: { state: 'open' } }))).mockRejectedValueOnce(new Error('timeout')))
    await (await endpoint('whatsapp-task-worker', f.client))(workerRequest())
    expect(f.updates[0].status).toBe('dead_letter')
  })
  it('programa nova tentativa quando a sessão está desconectada', async () => {
    const f = fixture()
    const fetcher = vi.fn().mockResolvedValueOnce(new Response(JSON.stringify({ instance: { state: 'close' } })))
    vi.stubGlobal('fetch', fetcher)
    await (await endpoint('whatsapp-task-worker', f.client))(workerRequest())
    expect(f.updates[0].status).toBe('retry')
    expect(fetcher).toHaveBeenCalledTimes(1)
  })
})
