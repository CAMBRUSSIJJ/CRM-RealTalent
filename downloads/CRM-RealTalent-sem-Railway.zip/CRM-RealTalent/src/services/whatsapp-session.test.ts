import { describe, expect, it, vi } from 'vitest'
import { createEvolution, EvolutionError, instanceName, qrImage } from '../../supabase/functions/_shared/evolution'
import { saveTaskWhatsAppPreference, whatsappSession } from './whatsapp-session'

describe('WhatsApp QR e notificações', () => {
  it('isola instâncias por workspace e rejeita caminhos arbitrários', () => {
    expect(instanceName('AAAAAAAA-0000-0000-0000-000000000001')).toBe('realtalent-aaaaaaaa-0000-0000-0000-000000000001')
    expect(() => instanceName('../outra-instancia')).toThrow()
  })
  it('aceita somente PNG inline, sem expor tokens a um gerador externo', () => {
    expect(qrImage('data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==')).toBe('data:image/png;base64,iVBORw0KGgoAAAANSUhEUg==')
    for (const value of ['https://example.com/qr', 'javascript:alert(1)', 'data:image/svg+xml;base64,abc', 'token-de-pareamento', null]) expect(qrImage(value)).toBeNull()
  })
  it('mantém autenticação no backend e bloqueia redirecionamento da credencial', async () => {
    const fetcher = vi.fn().mockResolvedValue(new Response(JSON.stringify({ instance: { state: 'open' } })))
    const api = createEvolution('https://evolution.example.com', 'test-key', fetcher)
    await api('/instance/connectionState/test')
    expect(fetcher.mock.calls[0][1]).toMatchObject({ headers: { apikey: 'test-key' }, redirect: 'error' })
    expect(() => createEvolution('http://example.com', 'key')).toThrow()
    expect(() => createEvolution('https://user:password@example.com', 'key')).toThrow()
  })
  it('não expõe corpo de erros do provedor, que pode conter credenciais', async () => {
    const api = createEvolution('https://example.com', 'test-key', vi.fn().mockResolvedValue(new Response('segredo-do-provedor', { status: 401 })))
    await expect(api('/instance/create', 'POST', {})).rejects.toBeInstanceOf(EvolutionError)
    await expect(api('/instance/create', 'POST', {})).rejects.not.toThrow('segredo-do-provedor')
  })
  it('nunca simula uma conexão ou um envio no modo local', async () => {
    await expect(whatsappSession('local', 'connect')).rejects.toThrow('modo local não envia')
    await expect(saveTaskWhatsAppPreference('local', '+55 11 99999-9999', true)).rejects.toThrow('modo local não envia')
  })
  it('exige um número internacional para autorizar avisos', async () => {
    await expect(saveTaskWhatsAppPreference('local', '123', true)).rejects.toThrow('código do país')
  })
})
