import { getSupabaseClient } from '../lib/supabase'

export interface WhatsAppSession { state: string; qr: string | null; expiresIn?: number; message?: string; connectionMode?: 'bridge' }
export interface TaskWhatsAppSettings {
  enabled: boolean
  preference: { phone: string; enabled: boolean } | null
  recent: Array<{ id: string; status: string; attempts: number; last_error: string | null; created_at: string }>
}
const clientRequired = () => {
  const client = getSupabaseClient()
  if (!client) throw new Error('Conecte o Supabase para usar o WhatsApp. O modo local não envia mensagens.')
  return client
}
export async function whatsappSession(organizationId: string, action: 'status' | 'connect' | 'disconnect'): Promise<WhatsAppSession> {
  const { data, error } = await clientRequired().functions.invoke('whatsapp-session', { body: { organizationId, action } })
  if (error) {
    let message = 'Não foi possível acessar o WhatsApp. Verifique se a função whatsapp-session foi publicada e configurada.'
    if (error.context instanceof Response) {
      const payload = await error.context.json().catch(() => null)
      if (typeof payload?.error === 'string') message = payload.error
    }
    throw new Error(message)
  }
  if (data?.error) throw new Error(data.error)
  return data as WhatsAppSession
}
export async function loadTaskWhatsAppSettings(organizationId: string) {
  const { data, error } = await clientRequired().rpc('get_task_whatsapp_settings', { p_organization_id: organizationId })
  if (error) throw new Error('Não foi possível carregar as notificações. Verifique se a migration do WhatsApp foi aplicada.')
  return data as unknown as TaskWhatsAppSettings
}
export async function saveTaskWhatsAppPreference(organizationId: string, phone: string, enabled: boolean) {
  const digits = phone.replace(/\D/g, '')
  if (enabled && !/^[1-9]\d{7,14}$/.test(digits)) throw new Error('Informe o número com código do país e DDD, por exemplo +55 11 99999-9999.')
  const { error } = await clientRequired().rpc('save_task_whatsapp_preference', { p_organization_id: organizationId, p_phone: digits, p_enabled: enabled })
  if (error) throw new Error('Não foi possível salvar seu número e sua autorização.')
}
export async function setTaskWhatsAppEnabled(organizationId: string, enabled: boolean) {
  const { error } = await clientRequired().rpc('set_task_whatsapp_enabled', { p_organization_id: organizationId, p_enabled: enabled })
  if (error) throw new Error('Não foi possível alterar os avisos do workspace. Verifique sua permissão de administrador.')
}
