export class EvolutionError extends Error {
  constructor(public status: number, public retryable: boolean) {
    super(status === 401 || status === 403 ? 'Credencial da Evolution API recusada. Revise o segredo do servidor.'
      : status === 404 ? 'Instância WhatsApp não encontrada.'
      : 'A Evolution API não concluiu a operação. Verifique o serviço e a conexão.')
  }
}

export const instanceName = (organizationId: string) => {
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(organizationId)) throw new Error('Workspace inválido')
  return 'realtalent-' + organizationId.toLowerCase()
}

export function qrImage(value: unknown): string | null {
  if (typeof value !== 'string' || value.length > 500_000) return null
  const data = value.replace(/^data:image\/png;base64,/, '')
  // Only inline PNGs from the authenticated backend; never send pairing tokens to QR websites.
  return /^iVBORw0KGgo[A-Za-z0-9+/=\r\n]+$/.test(data) ? 'data:image/png;base64,' + data : null
}

export function createEvolution(baseUrl: string, key: string, fetcher: typeof fetch = fetch) {
  const base = new URL(baseUrl)
  if (base.protocol !== 'https:' || base.username || base.password || base.search || base.hash) throw new Error('EVOLUTION_API_URL deve ser uma URL HTTPS sem credenciais')
  if (!key) throw new Error('Configure EVOLUTION_API_KEY no backend')
  return async (path: string, method = 'GET', body?: unknown) => {
    const response = await fetcher(base.toString().replace(/\/$/, '') + path, {
      method, headers: { apikey: key, 'content-type': 'application/json' },
      body: body === undefined ? undefined : JSON.stringify(body),
      signal: AbortSignal.timeout(15_000), redirect: 'error',
    })
    if (!response.ok) throw new EvolutionError(response.status, response.status === 429 || response.status >= 500)
    return await response.json()
  }
}
