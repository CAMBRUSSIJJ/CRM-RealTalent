import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4'
import { createEvolution, EvolutionError, instanceName, qrImage } from '../_shared/evolution.ts'

const cors = { 'access-control-allow-origin': '*', 'access-control-allow-headers': 'authorization, apikey, content-type, x-client-info', 'access-control-allow-methods': 'POST, OPTIONS' }
const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { ...cors, 'content-type': 'application/json', 'cache-control': 'no-store' } })

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors })
  if (req.method !== 'POST') return json({ error: 'Método não permitido' }, 405)
  try {
    const client = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_ANON_KEY')!, { global: { headers: { Authorization: req.headers.get('authorization') || '' } } })
    const { data: { user } } = await client.auth.getUser()
    if (!user) return json({ error: 'Sessão inválida' }, 401)
    const { organizationId, action } = await req.json()
    const instance = instanceName(organizationId)
    if (!['status', 'connect', 'disconnect'].includes(action)) return json({ error: 'Ação inválida' }, 400)
    const { data: member, error } = await client.from('organization_members').select('role').eq('organization_id', organizationId).eq('user_id', user.id).maybeSingle()
    if (error || !member) return json({ error: 'Acesso negado' }, 403)
    if (action !== 'status' && !['owner', 'admin'].includes(member.role)) return json({ error: 'Somente administradores podem conectar ou desconectar' }, 403)
    if (Deno.env.get('WHATSAPP_CONNECTION_MODE') === 'bridge') {
      const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
      const { data: bridge, error } = await admin.from('whatsapp_local_bridge').select('*').eq('organization_id', organizationId).maybeSingle()
      if (error) return json({ error: 'Aplique a migration do conector local no Supabase.' }, 503)
      const online = bridge?.heartbeat_at && Date.now() - new Date(bridge.heartbeat_at).getTime() < 45_000
      if (!online) {
        if (action !== 'status') return json({ error: 'Ligue o computador e inicie o conector local do WhatsApp.' }, 503)
        return json({ state: 'offline', qr: null, connectionMode: 'bridge' })
      }
      if (action === 'status') {
        const seconds = Math.floor((new Date(bridge.qr_expires_at || 0).getTime() - Date.now()) / 1000)
        const qr = ['owner', 'admin'].includes(member.role) && seconds > 0 && bridge.connection_state !== 'open' ? qrImage(bridge.qr_base64) : null
        return json({ state: bridge.connection_state, qr, expiresIn: Math.max(0, seconds), connectionMode: 'bridge', message: bridge.last_error })
      }
      const { error: updateError } = await admin.from('whatsapp_local_bridge').update({
        requested_action: action, request_id: crypto.randomUUID(), request_created_at: new Date().toISOString(),
        qr_base64: null, qr_expires_at: null, last_error: null,
      }).eq('organization_id', organizationId)
      if (updateError) return json({ error: 'Não foi possível solicitar a conexão ao computador.' }, 503)
      return json({ state: 'connecting', qr: null, connectionMode: 'bridge' })
    }
    const url = Deno.env.get('EVOLUTION_API_URL')
    const key = Deno.env.get('EVOLUTION_API_KEY')
    if (!url || !key) return json({ error: 'Configure EVOLUTION_API_URL e EVOLUTION_API_KEY nos segredos das funções Supabase.' }, 503)
    const evolution = createEvolution(url, key)
    if (action === 'disconnect') {
      await evolution('/instance/logout/' + instance, 'DELETE')
      return json({ state: 'close', qr: null })
    }
    let state = 'close'
    try {
      const result = await evolution('/instance/connectionState/' + instance)
      state = result.instance?.state || 'close'
    } catch (error) {
      if (!(error instanceof EvolutionError) || error.status !== 404) throw error
      if (action === 'status') return json({ state: 'missing', qr: null })
      try { await evolution('/instance/create', 'POST', { instanceName: instance, integration: 'WHATSAPP-BAILEYS', qrcode: true }) }
      catch (error) {
        // Evolution 2.3.7 returns 403 for a name created by another request.
        // Verify access to that instance instead of assuming every 403 is a conflict.
        if (!(error instanceof EvolutionError) || ![403, 409].includes(error.status)) throw error
        const existing = await evolution('/instance/connectionState/' + instance)
        if (!existing.instance?.state) throw error
        state = existing.instance.state
      }
    }
    if (state === 'open' || action === 'status') return json({ state, qr: null })
    const result = await evolution('/instance/connect/' + instance)
    const qr = qrImage(result.base64 || result.qrcode?.base64)
    return json({ state: 'connecting', qr, expiresIn: 40, message: qr ? null : 'O WhatsApp ainda está preparando o QR code. Aguarde e tente gerar novamente.' })
  } catch (error) {
    return json({ error: error instanceof EvolutionError ? error.message : 'Não foi possível consultar o WhatsApp. Confira a configuração e a disponibilidade do servidor.' }, 502)
  }
})
