import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.57.4'
import { createEvolution, EvolutionError, instanceName } from '../_shared/evolution.ts'

const json = (data: unknown, status = 200) => new Response(JSON.stringify(data), { status, headers: { 'content-type': 'application/json' } })
Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Método não permitido' }, 405)
  const secret = Deno.env.get('WHATSAPP_TASK_WORKER_SECRET') || ''
  if (secret.length < 32 || req.headers.get('x-worker-secret') !== secret) return json({ error: 'Não autorizado' }, 401)
  if (Deno.env.get('WHATSAPP_CONNECTION_MODE') === 'bridge') return json({ processed: 0, mode: 'bridge', message: 'Envio pelo conector local; desative o agendamento na nuvem.' })
  const url = Deno.env.get('EVOLUTION_API_URL')
  const key = Deno.env.get('EVOLUTION_API_KEY')
  if (!url || !key) return json({ error: 'Configure a Evolution API no backend' }, 503)
  const evolution = createEvolution(url, key)
  const admin = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!)
  const { data: items, error } = await admin.rpc('claim_task_whatsapp_batch')
  if (error) return json({ error: 'Não foi possível obter a fila' }, 500)
  const results = []
  for (const item of items || []) {
    let sending = false
    try {
      const [activity, preference, settings, member] = await Promise.all([
        admin.from('activities').select('assigned_to,completed_at,title,due_at').eq('id', item.activity_id).eq('organization_id', item.organization_id).maybeSingle(),
        admin.from('task_whatsapp_preferences').select('enabled,phone').eq('organization_id', item.organization_id).eq('user_id', item.user_id).maybeSingle(),
        admin.from('task_whatsapp_settings').select('enabled').eq('organization_id', item.organization_id).maybeSingle(),
        admin.from('organization_members').select('user_id').eq('organization_id', item.organization_id).eq('user_id', item.user_id).maybeSingle(),
      ])
      if ([activity, preference, settings, member].some(r => r.error)) throw new Error('Não foi possível verificar a atribuição')
      if (!member.data || !settings.data?.enabled || !preference.data?.enabled || preference.data.phone !== item.recipient ||
        activity.data?.assigned_to !== item.user_id || activity.data?.completed_at) {
        const { error } = await admin.from('task_whatsapp_outbox').update({ status: 'cancelled', locked_at: null }).eq('id', item.id)
        if (error) throw error
        results.push({ id: item.id, status: 'cancelled' }); continue
      }
      const instance = instanceName(item.organization_id)
      const connection = await evolution('/instance/connectionState/' + instance)
      if (connection.instance?.state !== 'open') throw new Error('WhatsApp desconectado; gere um novo QR code em Integrações.')
      sending = true
      const result = await evolution('/message/sendText/' + instance, 'POST', { number: item.recipient, text: item.body })
      const { error } = await admin.from('task_whatsapp_outbox').update({ status: 'sent', external_message_id: result.key?.id || null, last_error: null, locked_at: null }).eq('id', item.id)
      if (error) throw error
      results.push({ id: item.id, status: 'sent' })
    } catch (error) {
      // A timeout after POST can mean the message was sent. Avoid an automatic duplicate.
      const uncertain = sending && (!(error instanceof EvolutionError) || error.status >= 500)
      const retryable = !uncertain && (!(error instanceof EvolutionError) || error.retryable)
      const status = !retryable || item.attempts >= 5 ? 'dead_letter' : 'retry'
      const message = uncertain ? 'Entrega incerta após interrupção. Confira o WhatsApp antes de reenviar.'
        : error instanceof EvolutionError ? error.message : 'WhatsApp indisponível ou desconectado. Revise a conexão e o backend.'
      const { error: updateError } = await admin.from('task_whatsapp_outbox').update({
        status, last_error: message, locked_at: null,
        available_at: new Date(Date.now() + Math.min(3600, 30 * 2 ** item.attempts) * 1000).toISOString(),
      }).eq('id', item.id)
      if (updateError) return json({ error: 'Falha ao registrar o resultado; não reenvie sem verificar a entrega.' }, 500)
      results.push({ id: item.id, status })
    }
  }
  return json({ processed: results.length, results })
})
