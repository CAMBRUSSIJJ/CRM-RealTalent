begin;
create table public.task_whatsapp_preferences (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  phone text not null default '',
  enabled boolean not null default false,
  primary key (organization_id,user_id),
  foreign key (organization_id,user_id) references public.organization_members(organization_id,user_id) on delete cascade,
  check (not enabled or phone ~ '^[1-9][0-9]{7,14}$')
);
create table public.task_whatsapp_settings (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  enabled boolean not null default false
);
create table public.task_whatsapp_outbox (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  activity_id uuid not null references public.activities(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  recipient text not null,
  body text not null,
  status text not null default 'queued' check (status in ('queued','processing','sent','retry','cancelled','dead_letter')),
  attempts integer not null default 0,
  available_at timestamptz not null default now(),
  locked_at timestamptz,
  last_error text,
  external_message_id text,
  created_at timestamptz not null default now()
);
create index task_whatsapp_queue_idx on public.task_whatsapp_outbox(available_at) where status in ('queued','retry');
alter table public.task_whatsapp_preferences enable row level security;
alter table public.task_whatsapp_settings enable row level security;
alter table public.task_whatsapp_outbox enable row level security;
revoke all on public.task_whatsapp_preferences,public.task_whatsapp_settings,public.task_whatsapp_outbox from anon,authenticated;
grant all on public.task_whatsapp_preferences,public.task_whatsapp_settings,public.task_whatsapp_outbox to service_role;

create function public.get_task_whatsapp_settings(p_organization_id uuid)
returns jsonb language plpgsql security definer set search_path=public,pg_temp as $$
begin
  if auth.uid() is null or not public.is_organization_member(p_organization_id) then raise exception 'Acesso negado'; end if;
  return jsonb_build_object(
    'preference',(select jsonb_build_object('phone',phone,'enabled',enabled) from public.task_whatsapp_preferences where organization_id=p_organization_id and user_id=auth.uid()),
    'enabled',coalesce((select enabled from public.task_whatsapp_settings where organization_id=p_organization_id),false),
    'recent',(select coalesce(jsonb_agg(r),'[]'::jsonb) from (select id,status,attempts,last_error,created_at from public.task_whatsapp_outbox
      where organization_id=p_organization_id and (user_id=auth.uid() or public.is_organization_admin(p_organization_id)) order by created_at desc limit 10) r)
  );
end; $$;
create function public.save_task_whatsapp_preference(p_organization_id uuid,p_phone text,p_enabled boolean)
returns void language plpgsql security definer set search_path=public,pg_temp as $$
begin
  if auth.uid() is null or not public.is_organization_member(p_organization_id) then raise exception 'Acesso negado'; end if;
  insert into public.task_whatsapp_preferences(organization_id,user_id,phone,enabled)
    values(p_organization_id,auth.uid(),regexp_replace(coalesce(p_phone,''),'[^0-9]','','g'),p_enabled)
    on conflict (organization_id,user_id) do update set phone=excluded.phone,enabled=excluded.enabled;
  if not p_enabled then
    update public.task_whatsapp_outbox set status='cancelled' where organization_id=p_organization_id and user_id=auth.uid() and status in ('queued','retry');
  end if;
end; $$;
create function public.set_task_whatsapp_enabled(p_organization_id uuid,p_enabled boolean)
returns void language plpgsql security definer set search_path=public,pg_temp as $$
begin
  if auth.uid() is null or not public.is_organization_admin(p_organization_id) then raise exception 'Somente administradores podem configurar o envio'; end if;
  insert into public.task_whatsapp_settings values(p_organization_id,p_enabled)
    on conflict (organization_id) do update set enabled=excluded.enabled;
  if not p_enabled then
    update public.task_whatsapp_outbox set status='cancelled' where organization_id=p_organization_id and status in ('queued','retry');
  end if;
end; $$;

create function public.notify_task_assignment()
returns trigger language plpgsql security definer set search_path=public,pg_temp as $$
declare v_preference public.task_whatsapp_preferences; v_body text;
begin
  if TG_OP='UPDATE' and new.assigned_to is not distinct from old.assigned_to then return new; end if;
  update public.task_whatsapp_outbox set status='cancelled'
    where activity_id=new.id and status in ('queued','retry');
  if new.assigned_to is null or new.completed_at is not null or new.activity_type='note' then return new; end if;
  if not exists(select 1 from public.organization_members where organization_id=new.organization_id and user_id=new.assigned_to) then
    raise exception 'O responsável deve pertencer ao workspace';
  end if;
  v_body := 'Nova tarefa atribuída: ' || new.title || E'\nPrazo: ' ||
    case when new.due_at is null then 'Sem prazo' else to_char(new.due_at at time zone 'UTC','DD/MM/YYYY HH24:MI') || ' UTC' end;
  insert into public.seller_notifications(organization_id,user_id,lead_id,title,body,action_route,source_type,source_id)
    values(new.organization_id,new.assigned_to,new.lead_id,'Tarefa atribuída',v_body,'followups','task_assignment',gen_random_uuid()::text);
  if not exists(select 1 from public.task_whatsapp_settings where organization_id=new.organization_id and enabled) then return new; end if;
  select * into v_preference from public.task_whatsapp_preferences where organization_id=new.organization_id and user_id=new.assigned_to and enabled;
  if v_preference.user_id is null then return new; end if;
  insert into public.task_whatsapp_outbox(organization_id,activity_id,user_id,recipient,body)
    values(new.organization_id,new.id,new.assigned_to,v_preference.phone,v_body);
  return new;
end; $$;
create trigger task_assignment_notification after insert or update of assigned_to on public.activities
  for each row execute function public.notify_task_assignment();

create function public.claim_task_whatsapp_batch()
returns setof public.task_whatsapp_outbox language plpgsql security definer set search_path=public,pg_temp as $$
begin
  -- Interrupted sends have unknown results; do not resend them automatically.
  update public.task_whatsapp_outbox set status='dead_letter',last_error='Envio interrompido; confirme a entrega antes de reenviar.'
    where status='processing' and locked_at < now()-interval '10 minutes';
  return query update public.task_whatsapp_outbox q set status='processing',locked_at=now(),attempts=q.attempts+1
    where q.id in (select id from public.task_whatsapp_outbox where status in ('queued','retry') and available_at<=now()
      order by available_at limit 3 for update skip locked) returning q.*;
end; $$;
revoke all on function public.get_task_whatsapp_settings(uuid),public.save_task_whatsapp_preference(uuid,text,boolean),
  public.set_task_whatsapp_enabled(uuid,boolean),public.notify_task_assignment(),public.claim_task_whatsapp_batch() from public,anon,authenticated;
grant execute on function public.get_task_whatsapp_settings(uuid),public.save_task_whatsapp_preference(uuid,text,boolean),
  public.set_task_whatsapp_enabled(uuid,boolean) to authenticated;
grant execute on function public.claim_task_whatsapp_batch() to service_role;
commit;
