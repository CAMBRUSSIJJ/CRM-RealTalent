-- Outbound-only connector: no publicly reachable Evolution server is required.
begin;
create table public.whatsapp_local_bridge (
  organization_id uuid primary key references public.organizations(id) on delete cascade,
  heartbeat_at timestamptz,
  connection_state text not null default 'close',
  qr_base64 text check (length(qr_base64) <= 500000),
  qr_expires_at timestamptz,
  requested_action text check (requested_action in ('connect','disconnect')),
  request_id uuid,
  claimed_request_id uuid,
  request_created_at timestamptz,
  completed_request_id uuid,
  last_error text
);
alter table public.whatsapp_local_bridge enable row level security;
revoke all on public.whatsapp_local_bridge from anon,authenticated;
grant all on public.whatsapp_local_bridge to service_role;

create function public.claim_whatsapp_bridge_action(p_organization_id uuid)
returns setof public.whatsapp_local_bridge language sql security definer set search_path=public,pg_temp as $$
  update public.whatsapp_local_bridge set claimed_request_id=request_id
    where organization_id=p_organization_id and requested_action is not null
      and request_id is distinct from claimed_request_id and request_created_at > now()-interval '2 minutes'
    returning *;
$$;
revoke all on function public.claim_whatsapp_bridge_action(uuid) from public,anon,authenticated;
grant execute on function public.claim_whatsapp_bridge_action(uuid) to service_role;

create function public.claim_local_whatsapp_batch(p_organization_id uuid)
returns setof public.task_whatsapp_outbox language plpgsql security definer set search_path=public,pg_temp as $$
begin
  update public.task_whatsapp_outbox set status='dead_letter',last_error='Envio interrompido; confirme a entrega antes de reenviar.'
    where organization_id=p_organization_id and status='processing' and locked_at < now()-interval '10 minutes';
  return query update public.task_whatsapp_outbox q set status='processing',locked_at=now(),attempts=q.attempts+1
    where q.id in (select id from public.task_whatsapp_outbox where organization_id=p_organization_id
      and status in ('queued','retry') and available_at<=now() order by available_at limit 3 for update skip locked) returning q.*;
end; $$;
revoke all on function public.claim_local_whatsapp_batch(uuid) from public,anon,authenticated;
grant execute on function public.claim_local_whatsapp_batch(uuid) to service_role;
commit;
