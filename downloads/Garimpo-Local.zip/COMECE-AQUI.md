# Instalação no computador

Abra deploy/local-garimpo/README.md e siga as três etapas: Firecrawl, modelo local e conector. No Windows, o iniciador fica em deploy/local-garimpo/INICIAR-WINDOWS.cmd.

Os endpoints e a fila já foram publicados no Supabase do CRM. A interface desta atualização está na branch de implementação; publique-a para gerar garimpo.env pelo Garimpo. Não compartilhe o arquivo de acesso.
