# V100.84.0 — Calendar Integration 2.0

## Objetivo
Transformar a infraestrutura existente de calendário em uma integração operacional e observável no CRM, sem simular conexão externa quando Supabase/OAuth não estão configurados.

## Entregas
- Configurações > Agenda externa com Google Agenda e Microsoft Calendar.
- OAuth PKCE existente exposto em fluxo orientado, com novo escopo Google para listar calendários.
- Escolha do calendário alvo e direção: bidirecional, CRM → provedor ou provedor → CRM.
- Conta padrão pessoal ou do workspace para escrita da Agenda.
- Pull incremental manual, publicação inicial de eventos locais, renovação de webhook e teste da conta.
- Status de jobs, eventos vinculados, conflitos e assinatura/webhook.
- Resolução de conflito: manter CRM, manter provedor ou ignorar.
- Criação, atualização e cancelamento externos com idempotência por evento/versão.
- Google atualiza com PATCH; Microsoft cria no calendário selecionado e lê delta do calendário selecionado.
- Lembretes sincronizados e metadados internos da Agenda não vazam para a descrição externa.
- Trocar de calendário reinicia o cursor incremental e agenda renovação/sincronização.
- Deduplicação da primeira sincronização para reduzir eventos duplicados.
- Atalho direto Agenda → Agenda externa.

## Escopo de Follow-ups
A integração sincroniza os tipos existentes da Agenda RealTalent, inclusive eventos de tipo follow-up. Uma atividade que existe apenas na fila de Follow-ups não é transformada automaticamente em evento externo; ela precisa também estar registrada como compromisso da Agenda.

## Banco
Adicionada a migration `202609220001_v100_84_calendar_integration.sql`, com configuração segura da conta/calendário e backfill de eventos locais sem vínculo externo. O schema de backup do CRM permanece `100.54`.
