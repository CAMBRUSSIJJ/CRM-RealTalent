#!/usr/bin/env node
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import {fileURLToPath} from 'node:url'
import {createHash,randomUUID} from 'node:crypto'
import {spawnSync} from 'node:child_process'

const packageRoot=path.dirname(fileURLToPath(import.meta.url))
const digest=data=>data===null?null:createHash('sha256').update(data).digest('hex')
const optional=async file=>{try{return await fs.readFile(file)}catch(error){if(error.code==='ENOENT')return null;throw error}}
async function atomicWrite(file,data,mode=0o644){
  const temporary=path.join(path.dirname(file),`.${path.basename(file)}.${randomUUID()}.tmp`)
  try{await fs.writeFile(temporary,data,{mode,flag:'wx'});await fs.rename(temporary,file)}
  finally{await fs.rm(temporary,{force:true})}
}
async function main(){
  const [major,minor]=process.versions.node.split('.').map(Number)
  if(major!==22||minor<12)throw Error('Use o Node.js 22.12 ou superior da linha 22, como exige o aplicativo.')
  let action='apply',repoInput=path.join(os.homedir(),'.local/share/realtalent-ai/repo'),noRestart=false
  const args=process.argv.slice(2)
  for(let index=0;index<args.length;index++){
    const arg=args[index]
    if(arg==='--repo'&&args[index+1])repoInput=args[++index]
    else if(arg==='--no-restart')noRestart=true
    else if(['--check','--restore'].includes(arg)&&action==='apply')action=arg.slice(2)
    else throw Error(`Argumento inválido: ${arg}`)
  }
  const repoRoot=await fs.realpath(repoInput)
  const manifest=JSON.parse(await fs.readFile(path.join(packageRoot,'manifest.json'),'utf8'))
  const backupRoot=path.join(path.dirname(repoRoot),'quality-v61-backups')
  const pointer=path.join(backupRoot,'latest.json')
  const target=async relative=>{
    const file=path.resolve(repoRoot,relative)
    const parent=await fs.realpath(path.dirname(file))
    if(!file.startsWith(repoRoot+path.sep)||!parent.startsWith(repoRoot+path.sep))throw Error('Caminho fora da instalação.')
    try{if((await fs.lstat(file)).isSymbolicLink())throw Error(`Arquivo é link simbólico: ${relative}`)}
    catch(error){if(error.code!=='ENOENT')throw error}
    return file
  }
  async function saveState(folder,state){
    await atomicWrite(path.join(folder,'backup.json'),JSON.stringify(state,null,2)+'\n',0o600)
  }
  async function restore(folder){
    const state=JSON.parse(await fs.readFile(path.join(folder,'backup.json'),'utf8'))
    if(state.repoRoot!==repoRoot||state.files.length!==manifest.files.length)throw Error('Backup pertence a outra instalação.')
    const operations=[]
    for(const entry of state.files){
      const known=manifest.files.find(file=>file.path===entry.path&&file.before===entry.before&&file.after===entry.after)
      if(!known)throw Error('Backup incompatível com este pacote.')
      const file=await target(entry.path),current=await optional(file),hash=digest(current)
      if(hash!==entry.before&&hash!==entry.after)throw Error(`Arquivo alterado depois da atualização: ${entry.path}. Preservado.`)
      const original=entry.before===null?null:await fs.readFile(path.join(folder,entry.path))
      if(digest(original)!==entry.before)throw Error(`Backup corrompido: ${entry.path}`)
      operations.push({file,original,mode:entry.mode})
    }
    for(const operation of operations){
      if(operation.original===null)await fs.rm(operation.file,{force:true})
      else await atomicWrite(operation.file,operation.original,operation.mode)
    }
    state.status='restored'
    await saveState(folder,state)
  }
  async function restart(){
    if(noRestart)return
    const result=spawnSync('systemctl',['--user','restart','realtalent-ai-agent.service'],{encoding:'utf8'})
    if(result.error||result.status!==0)throw Error('Não foi possível reiniciar realtalent-ai-agent.service.')
    for(let attempt=0;attempt<10;attempt++){
      try{
        const response=await fetch('http://127.0.0.1:8792/tools/health',{signal:AbortSignal.timeout(3000)})
        const data=await response.json()
        if(response.ok&&data.ok===true)return
      }catch{ /* wait for the agent to load */ }
      await new Promise(resolve=>setTimeout(resolve,1000))
    }
    throw Error('O agente não respondeu à verificação de saúde depois de reiniciar.')
  }
  if(action==='restore'){
    const selected=JSON.parse(await fs.readFile(pointer,'utf8'))
    if(typeof selected.folder!=='string'||path.basename(selected.folder)!==selected.folder)throw Error('Referência de backup inválida.')
    const folder=path.join(backupRoot,selected.folder)
    await restore(folder)
    console.log('Arquivos anteriores restaurados.')
    await restart()
    return
  }
  const operations=[]
  for(const entry of manifest.files){
    const file=await target(entry.path),original=await optional(file),hash=digest(original)
    const updated=await fs.readFile(path.join(packageRoot,'arquivos',entry.path))
    if(digest(updated)!==entry.after)throw Error(`Pacote corrompido: ${entry.path}`)
    if(hash!==entry.before&&hash!==entry.after)throw Error(`Versão incompatível ou edição local: ${entry.path}. Nenhum arquivo foi alterado.`)
    const mode=original===null?0o644:(await fs.stat(file)).mode&0o777
    operations.push({entry,file,original,updated,mode,hash})
  }
  for(const dependency of manifest.dependencies){
    if(digest(await optional(await target(dependency.path)))!==dependency.sha256)
      throw Error(`Dependência incompatível: ${dependency.path}. Nenhum arquivo foi alterado.`)
  }
  const applied=operations.every(item=>item.hash===item.entry.after)
  const original=operations.every(item=>item.hash===item.entry.before)
  if(!applied&&!original)throw Error('Atualização parcial detectada. Use restaurar-linux.sh antes de tentar novamente.')
  console.log(`Instalação: ${repoRoot}`)
  if(applied){console.log('Esta melhoria já está aplicada.');return}
  if(action==='check'){console.log('Compatível. Nenhum arquivo foi alterado.');return}
  const name=new Date().toISOString().replace(/[:.]/g,'-')+'-'+randomUUID().slice(0,8)
  const folder=path.join(backupRoot,name)
  await fs.mkdir(folder,{recursive:true,mode:0o700})
  const state={repoRoot,status:'prepared',files:operations.map(({entry,mode})=>({...entry,mode}))}
  for(const item of operations){
    if(item.original!==null){
      const file=path.join(folder,item.entry.path)
      await fs.mkdir(path.dirname(file),{recursive:true,mode:0o700})
      await fs.writeFile(file,item.original,{mode:0o600,flag:'wx'})
    }
  }
  await saveState(folder,state)
  await atomicWrite(pointer,JSON.stringify({folder:name})+'\n',0o600)
  try{
    for(const item of operations){
      if(digest(await optional(item.file))!==item.hash)throw Error(`Arquivo mudou durante a atualização: ${item.entry.path}`)
      await atomicWrite(item.file,item.updated,item.mode)
    }
    await restart()
    state.status='applied'
    await saveState(folder,state)
    console.log('Melhoria aplicada. Backup: '+folder)
    if(noRestart)console.log('Reinício não solicitado; o agente ainda precisa ser reiniciado para carregar os arquivos.')
  }catch(error){
    try{await restore(folder);await restart();console.error('A atualização falhou; os arquivos anteriores foram restaurados.')}
    catch(restoreError){console.error('Verifique o backup em '+folder+'. '+restoreError.message)}
    throw error
  }
}
main().catch(error=>{console.error('ERRO: '+error.message);process.exitCode=1})
