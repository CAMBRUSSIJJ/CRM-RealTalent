import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs/promises'
import path from 'node:path'
import os from 'node:os'
import {fileURLToPath} from 'node:url'
import {spawnSync} from 'node:child_process'
import {createHash} from 'node:crypto'

const packageRoot=path.dirname(fileURLToPath(import.meta.url))
const manifest=JSON.parse(await fs.readFile(path.join(packageRoot,'manifest.json'),'utf8'))
const hash=data=>createHash('sha256').update(data).digest('hex')
async function fixture(t){
  const root=await fs.mkdtemp(path.join(os.tmpdir(),'realtalent-quality-test-'))
  t.after(()=>fs.rm(root,{recursive:true,force:true}))
  const repo=path.join(root,'repo')
  for(const entry of manifest.files.filter(entry=>entry.before!==null)){
    const file=path.join(repo,entry.path)
    await fs.mkdir(path.dirname(file),{recursive:true})
    await fs.copyFile(path.join(packageRoot,'originais',entry.path),file)
  }
  for(const entry of manifest.dependencies)
    await fs.copyFile(path.join(packageRoot,'arquivos',entry.path),path.join(repo,entry.path))
  return {root,repo}
}
const run=(repo,args=[],options={})=>spawnSync(process.execPath,
  [path.join(options.packageRoot||packageRoot,'aplicar-melhoria.mjs'),'--repo',repo,...args],
  {encoding:'utf8',env:options.env||process.env})
async function assertVersion(repo,version){
  for(const entry of manifest.files){
    const file=path.join(repo,entry.path)
    if(entry[version]===null)await assert.rejects(fs.stat(file),{code:'ENOENT'})
    else assert.equal(hash(await fs.readFile(file)),entry[version],entry.path)
  }
}

test('compatibility check does not change files or create backups',async t=>{
  const {root,repo}=await fixture(t)
  const checked=run(repo,['--check'])
  assert.equal(checked.status,0,checked.stderr)
  await assertVersion(repo,'before')
  await assert.rejects(fs.stat(path.join(root,'quality-v61-backups')),{code:'ENOENT'})
})

test('apply, repeated apply and restore preserve the exact previous files',async t=>{
  const {root,repo}=await fixture(t)
  const applied=run(repo,['--no-restart'])
  assert.equal(applied.status,0,applied.stderr)
  await assertVersion(repo,'after')
  const backups=await fs.readdir(path.join(root,'quality-v61-backups'))
  assert.equal(run(repo,['--no-restart']).status,0)
  assert.deepEqual(await fs.readdir(path.join(root,'quality-v61-backups')),backups)
  const restored=run(repo,['--restore','--no-restart'])
  assert.equal(restored.status,0,restored.stderr)
  await assertVersion(repo,'before')
})

test('incompatible installation is rejected before any mutation',async t=>{
  const {root,repo}=await fixture(t)
  const changed=path.join(repo,manifest.files[0].path)
  const localEdit=(await fs.readFile(changed,'utf8'))+'\n// edição local\n'
  await fs.writeFile(changed,localEdit)
  const out=run(repo,['--no-restart'])
  assert.notEqual(out.status,0)
  assert.match(out.stderr,/incompatível|edição local/)
  assert.equal(await fs.readFile(changed,'utf8'),localEdit)
  for(const entry of manifest.files.slice(1).filter(entry=>entry.before!==null))
    assert.equal(hash(await fs.readFile(path.join(repo,entry.path))),entry.before)
  await assert.rejects(fs.stat(path.join(root,'quality-v61-backups')),{code:'ENOENT'})
})

test('restore refuses to overwrite edits made after the update',async t=>{
  const {repo}=await fixture(t)
  assert.equal(run(repo,['--no-restart']).status,0)
  const changed=path.join(repo,manifest.files[0].path)
  const localEdit=(await fs.readFile(changed,'utf8'))+'\n// edição posterior\n'
  await fs.writeFile(changed,localEdit)
  const restored=run(repo,['--restore','--no-restart'])
  assert.notEqual(restored.status,0)
  assert.match(restored.stderr,/alterado depois/)
  assert.equal(await fs.readFile(changed,'utf8'),localEdit)
  for(const entry of manifest.files.slice(1))
    assert.equal(hash(await fs.readFile(path.join(repo,entry.path))),entry.after)
})

test('failed service restart restores the original files automatically',async t=>{
  const {root,repo}=await fixture(t)
  const bin=path.join(root,'bin')
  await fs.mkdir(bin)
  await fs.writeFile(path.join(bin,'systemctl'),'#!/bin/sh\nexit 1\n',{mode:0o755})
  const out=run(repo,[],{env:{...process.env,PATH:bin}})
  assert.notEqual(out.status,0)
  assert.match(out.stderr,/reiniciar/)
  await assertVersion(repo,'before')
})

test('damaged update package is rejected before changing the installation',async t=>{
  const {root,repo}=await fixture(t)
  const copy=path.join(root,'package')
  await fs.cp(packageRoot,copy,{recursive:true})
  await fs.appendFile(path.join(copy,'arquivos',manifest.files[0].path),'\n// alteração do pacote\n')
  const out=run(repo,['--no-restart'],{packageRoot:copy})
  assert.notEqual(out.status,0)
  assert.match(out.stderr,/Pacote corrompido/)
  await assertVersion(repo,'before')
})
