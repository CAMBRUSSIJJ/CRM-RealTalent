#!/usr/bin/env bash
set -Eeuo pipefail
PACKAGE_DIR="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
exec node --test "$PACKAGE_DIR/arquivos/runtime-host/RealTalent-Agent-Runtime-V3.1.2/"*.test.mjs "$PACKAGE_DIR/instalacao.test.mjs"
