# Garimpo no Linux

1. Na prévia do CRM, em Garimpo → Busca → Configurar ou verificar meu Linux, gere garimpo.env.
2. Salve garimpo.env em deploy/local-garimpo/.
3. Nessa pasta, execute bash CONFIGURAR-LINUX.sh.
4. Escolha qwen2.5-coder:3b e faça o primeiro teste com uma empresa.

O configurador usa o perfil econômico em máquinas de até 10 GiB e não bloqueia a instalação pela memória livre. Guia completo: deploy/local-garimpo/README.md.
