# Garimpo no Linux

1. Na prévia do CRM, em Garimpo → Busca → Configurar ou verificar meu Linux, gere garimpo.env.
2. Salve garimpo.env em deploy/local-garimpo/.
3. Nessa pasta, execute bash CONFIGURAR-LINUX.sh.

Em até 10 GiB de RAM, o configurador usa o perfil econômico. Libere pelo menos 2,5 GiB de memória disponível antes da primeira compilação. Comece pelo menor modelo instalado e pelo teste de uma empresa.

Guia: deploy/local-garimpo/README.md.
