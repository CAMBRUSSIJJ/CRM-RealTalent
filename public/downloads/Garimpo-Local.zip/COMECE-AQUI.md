# Garimpo no Linux

1. No CRM, em Garimpo → Busca → Configurar ou verificar meu Linux, gere garimpo.env.
2. Salve esse arquivo em deploy/local-garimpo/.
3. Nessa pasta, execute bash CONFIGURAR-LINUX.sh.

Docker, Ollama, Git e Node.js 22.18 ou superior precisam estar instalados. O configurador mostra os modelos disponíveis e prepara o Firecrawl. O guia completo está em deploy/local-garimpo/README.md.
