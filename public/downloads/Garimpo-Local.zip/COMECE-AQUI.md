# Garimpo no Linux

1. Na prévia do CRM, abra Garimpo → Busca → Configurar ou verificar meu Linux e gere garimpo.env.
2. Salve garimpo.env em deploy/local-garimpo/.
3. Nessa pasta, execute bash CONFIGURAR-LINUX.sh.

Requisitos: Docker/Compose, Ollama, Git e Node.js 22.18 ou superior. Em computadores de até 10 GiB, o configurador usa o perfil econômico e pede pelo menos 2,5 GiB disponíveis antes de compilar. Comece pelo modelo menor já instalado e pelo teste de uma empresa.

Guia completo: deploy/local-garimpo/README.md.
